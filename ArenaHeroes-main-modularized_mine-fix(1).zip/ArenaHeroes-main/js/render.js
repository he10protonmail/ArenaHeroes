import { ROWS, COLS, STATUS, ABILITIES } from "./state.js";
import { getCell, DEFAULT_TERRAIN } from "./board.js";
import { statusIcons, isBattleUnit, safeColor } from "./units.js";
import { templates, terrainTools } from "./config.js";
import { setText } from "./ui.js";
import { colName, coordLabel } from "./board.js";
import { hitChance, ABILITY_HIT_MALUS } from "./combat.js";
import { store } from "./store.js";
import { getCurrentUnit, atAny, hasStatus, coreAt, attackRangeTiles, isAiTurn, effectiveDefense, isCoreOpen } from "./selectors.js";

export function esc(v) { return String(v ?? "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;"); }
// Bild-URLs werden in HTML-Style-Attributen interpoliert (siehe renderUnitForm/
// renderTerrainForm). Normale Uploads sind immer data:image/...-URLs ohne
// Sonderzeichen, aber eine von Hand bearbeitete gespeicherte Karte könnte hier
// beliebigen Text einschleusen und aus dem style-Attribut ausbrechen. Deshalb:
// nur echte data:image/-URLs durchlassen, plus esc() als zusätzliche Absicherung.
// Nur echte data:image/-URLs werden als Bild interpoliert - eine von Hand bearbeitete
// gespeicherte Karte könnte sonst beliebigen Text in ein style-Attribut einschleusen.
// Zentral an einer Stelle, damit jede Interpolationsstelle (Formulare, Board-Kacheln,
// Einheiten-/Geist-Vorschau) dieselbe Prüfung nutzt statt eigener Kopien.
function safeImageUrl(image) {
  return /^data:image\//i.test(image || "") ? image : "";
}
function previewStyle(image) {
  const safe = safeImageUrl(image);
  return safe ? `background-image:url('${esc(safe)}')` : "";
}
function terrainStyle(cell) {
  const safe = safeImageUrl(cell?.image);
  return safe ? `background-image:url("${safe}")` : "";
}
// Trefferchance (0..1) für das Ziel auf diesem Feld im aktuellen Modus - oder null, wenn nichts gewürfelt wird
// (Heilen, Minen, eigenes Team, kein Ziel). Spiegelt exakt die Würfe in battle.js wider.
function targetHitChance(attacker, unit, core) {
  const mode = store.state.mode;
  if (!attacker || (mode !== "attack" && mode !== "ability")) return null;
  const malus = mode === "ability" ? ABILITY_HIT_MALUS : 0;
  if (mode === "ability" && (attacker.abilityType === "heal" || attacker.abilityType === "trap")) return null;
  if (unit) return unit.team !== attacker.team ? hitChance(attacker, effectiveDefense(unit), malus) : null;
  // Core-Angriffe gibt es nur im Angriffsmodus; Verteidigung eines Cores = Deckung seines Feldes
  if (core && mode === "attack" && attacker.team !== "enemy" && !(core.hp <= 0))
    return hitChance(attacker, Number(getCell(store.board, core.x, core.y)?.cover || 0), 0);
  return null;
}

function renderBoard(element) {
  if (!element) return;
  element.innerHTML = "";
  delete element.dataset.rangeFor; // eine evtl. angezeigte Hover-Vorschau ist mit dem alten DOM verschwunden
  // Angriffsreichweite der aktiven Einheit (nur im laufenden Kampf) als dezentes Overlay
  const activeUnit = element.id === "board" && !store.state.victory && !store.state.defeat ? getCurrentUnit() : null;
  const rangeKeys = new Set(attackRangeTiles(activeUnit).map(p => `${p.x},${p.y}`));
  for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) {
    const cell = getCell(store.board, x, y), tile = document.createElement("div");
    tile.className = `tile ${cell?.type || "floor"} ${cell?.image ? "has-image" : ""} ${cell?.type === "core" && cell?.walk ? "core-open" : ""}`;
    tile.style.cssText = terrainStyle(cell);
    tile.dataset.x = x; tile.dataset.y = y;
    const h = store.state.highlight.find(p => p.x === x && p.y === y);
    if (h) tile.classList.add(store.state.mode === "move" ? "move-range" : store.state.mode === "ability" ? "ability-range" : "attack-range");
    if (rangeKeys.has(`${x},${y}`)) tile.classList.add("range-view", `rv-${activeUnit.team}`);
    const trap = store.state.traps.find(t => t.x === x && t.y === y);
    if (trap) { const n = document.createElement("span"); n.className = "trap"; n.textContent = "✹"; tile.appendChild(n); }
    const u = atAny(x, y);
    const core = coreAt(x, y);
    if (core) {
      const status = cell?.walk ? (core.entered ? "entered" : "open – enter to win") : `closed, HP ${core.hp}/${core.maxHp}`;
      const n = document.createElement("span"); n.className = "trap"; n.textContent = "💠";
      n.title = `${core.name} – ${status}`;
      tile.appendChild(n);
      // Beschriftung "Core N" + Lebensleiste auf dem Feld (entfällt, solange eine Einheit darauf steht)
      if (!u) {
        const l = document.createElement("span"); l.className = "core-label"; l.textContent = core.name; tile.appendChild(l);
        const bar = document.createElement("div"); bar.className = "core-hpbar";
        bar.innerHTML = `<span style="width:${Math.max(0, (core.hp / (core.maxHp || 1)) * 100)}%"></span>`;
        tile.appendChild(bar);
      }
    }
    // Koordinaten am Rand (Schachbrett-Stil): Buchstaben oben/unten, Zahlen links/rechts
    for (const [show, cls, text] of [[y === 0, "top", colName(x)], [y === ROWS - 1, "bottom", colName(x)], [x === 0, "left", String(y + 1)], [x === COLS - 1, "right", String(y + 1)]]) {
      if (!show) continue;
      const lab = document.createElement("span"); lab.className = `coord coord-${cls}`; lab.textContent = text; tile.appendChild(lab);
    }
    // Trefferchance als kleines Etikett auf jedem markierten Ziel (nur auf dem Kampffeld, nicht im KI-Zug)
    if (h && activeUnit && !isAiTurn()) {
      const chance = targetHitChance(activeUnit, u, core && !isCoreOpen(core) ? core : null);
      if (chance !== null) {
        const pct = Math.round(chance * 100), c = document.createElement("span");
        c.className = `hit-chance ${pct >= 65 ? "hc-high" : pct >= 35 ? "hc-mid" : "hc-low"}`;
        c.textContent = `${pct}%`; c.title = `Hit chance ${pct}%`;
        tile.appendChild(c);
      }
    }
    const isEditorBoard = element.id === "editor-board";
    const draft = isEditorBoard && store.state.editorDraft?.isNew ? store.state.editorDraft.unit : null;
    if (!u && draft && draft.x === x && draft.y === y) {
      // Vorschau ("Geist") der neuen Einheit an der gewählten Position
      const g = document.createElement("div");
      g.className = `unit ghost ${draft.team} ${draft.image ? "has-image" : ""}`;
      g.style.backgroundColor = safeColor(draft.color);
      const draftImg = safeImageUrl(draft.image);
      if (draftImg) { g.style.backgroundImage = `url("${draftImg}")`; g.style.backgroundSize = "cover"; g.style.backgroundPosition = "center"; }
      g.innerHTML = `<div class="unit-core"><span class="unit-short">${draft.image ? "" : esc(draft.short || "?")}</span></div>`;
      tile.appendChild(g);
    }
    if (u) {
      const n = document.createElement("div");
      if (isEditorBoard && u.alive) n.draggable = true;
      n.className = `unit ${u.team} ${u.image ? "has-image" : ""} ${u.id === getCurrentUnit()?.id ? "selected" : ""} ${u.alive ? "" : "defeated"}`;
      n.dataset.unitId = u.id;
      n.title = `${u.name} – Range ${u.range ?? 0}`;
      n.style.backgroundColor = safeColor(u.color);
      const uImg = safeImageUrl(u.image);
      if (uImg) { n.style.backgroundImage = `url("${uImg}")`; n.style.backgroundSize = "cover"; n.style.backgroundPosition = "center"; }
      n.innerHTML = `<div class="unit-core"><span class="unit-short">${u.alive ? (u.image ? "" : esc(u.short || "?")) : "☠"}</span><span class="unit-status">${statusIcons(u, STATUS)}</span></div><div class="unit-hpbar"><span style="width:${Math.max(0, (u.hp / (u.maxHp || 1)) * 100)}%"></span></div><div class="unit-hptext">${u.hp}/${u.maxHp}</div>`;
      tile.appendChild(n);
    }
    element.appendChild(tile);
  }
}
function renderInitiative() {
  const list = document.getElementById("initiative-list"); if (!list) return;
  list.innerHTML = store.state.turnOrder.filter(isBattleUnit).map(u => `<div class="card ${u.id === getCurrentUnit()?.id ? "active" : ""}"><span>${esc(u.name)}</span><span>HP ${u.hp}/${u.maxHp} · AP ${u.ap || 0} · RW ${u.range ?? 0}</span></div>`).join("") || '<div class="small">No units.</div>';
}
function renderSelectedUnitCard() {
  const c = document.getElementById("selected-unit-card"); if (!c) return;
  const u = getCurrentUnit();
  c.innerHTML = u ? `<h4>${esc(u.name)}</h4><div>${u.team === "hero" ? "Hero" : "Enemy"} · ${esc(u.className)}</div><div class="stats"><span>HP</span><b>${u.hp}/${u.maxHp}</b></div><div class="stats"><span>AP</span><b>${u.ap}</b></div><div class="stats"><span>Movement</span><b>${u.moveLeft}</b></div><div class="stats"><span>Attack range</span><b>${u.range ?? 0} tiles</b></div>${u.abilityType && u.abilityType !== "none" && (u.abilityRange ?? u.range) !== u.range ? `<div class="stats"><span>Special range</span><b>${u.abilityRange} tiles</b></div>` : ""}<div class="stats"><span>Attack/Damage</span><b>${u.attack}/${u.damage || "-"}</b></div><div class="ability">${esc(u.abilityName || "None")} · Knockback ${u.knockback || 0} · Stability ${u.stability || 0}</div>` : '<div class="small">No active unit.</div>';
}
// Missionsziele mit Fortschritt: welche Kerne sind noch zu, offen oder schon betreten
function renderMissionPanel() {
  const n = document.getElementById("mission-list"); if (!n) return;
  const enemies = store.state.units.filter(u => u.team === "enemy");
  const rows = [];
  if (store.state.cores.length) {
    const entered = store.state.cores.filter(c => c.entered).length;
    rows.push(`<div class="stats"><span>Enter all cores</span><b>${entered}/${store.state.cores.length}</b></div>`);
    for (const c of store.state.cores) {
      const open = !!getCell(store.board, c.x, c.y)?.walk;
      rows.push(`<div class="small">${esc(c.name)}: ${c.entered ? "entered ✓" : open ? "open – enter it!" : `closed (HP ${c.hp}/${c.maxHp})`}</div>`);
    }
  }
  if (enemies.length) rows.push(`<div class="stats"><span>Or defeat all enemies</span><b>${enemies.filter(u => !u.alive).length}/${enemies.length}</b></div>`);
  n.innerHTML = rows.join("") || '<div class="small">No mission objective defined.</div>';
}
// Reichweiten-Vorschau: zeigt die Angriffsreichweite einer beliebigen Einheit (Mauszeiger darüber).
// Arbeitet direkt an den vorhandenen Kacheln, ohne das Board neu zu zeichnen.
export function showRangePreview(unitId) {
  const board = document.getElementById("board"); if (!board) return;
  board.querySelectorAll(".range-hover").forEach(t => t.classList.remove("range-hover", "rv-hero", "rv-enemy"));
  board.dataset.rangeFor = unitId || "";
  const u = store.state.units.find(v => v.id === unitId);
  if (!u || !isBattleUnit(u) || store.state.victory || store.state.defeat) return;
  for (const p of attackRangeTiles(u)) board.children[p.y * COLS + p.x]?.classList.add("range-hover", `rv-${u.team}`);
}
// Statusübersicht oben rechts: alle Einheiten im Kampf mit aktiven Statuseffekten (z.B. "Betäubt") und Restdauer.
function renderStatusOverview() {
  const n = document.getElementById("status-overview"); if (!n) return;
  const inBattle = store.state.screen === "battle";
  n.classList.toggle("hidden", !inBattle);
  if (!inBattle) return;
  const chips = store.state.units.filter(u => isBattleUnit(u) && u.statuses?.length).map(u => {
    const list = u.statuses.map(s => `${STATUS[s.id]?.icon || "?"} ${esc(STATUS[s.id]?.label || s.id)} (${s.remaining})`).join(", ");
    return `<span class="status-chip status-chip--${u.team === "enemy" ? "enemy" : "hero"}"><b>${esc(u.name)}</b> ${list}</span>`;
  });
  n.innerHTML = chips.join("") || '<span class="small">No status effects</span>';
}
function renderBattleLog() { const n = document.getElementById("battle-log"); if (n) n.innerHTML = store.state.log.map(x => `<div>${esc(x)}</div>`).join("") || '<div class="small">No events yet.</div>'; }
function renderBattleScreen() {
  document.getElementById("battle-screen")?.classList.remove("hidden"); document.getElementById("editor-screen")?.classList.add("hidden");
  setText("battle-state-title", store.state.victory ? "Victory" : store.state.defeat ? "Defeat" : "Battle");
  setText("battle-round-label", `Round ${store.state.round}${getCurrentUnit() ? ` · ${getCurrentUnit().name}` : ""}${isAiTurn() ? " (AI acting …)" : ""}`);
  renderBoard(document.getElementById("board")); renderInitiative(); renderSelectedUnitCard(); renderMissionPanel(); renderBattleLog();
  updateActionButtons();
  const overlay = document.getElementById("battle-overlay");
  if (overlay) overlay.classList.toggle("hidden", !(store.state.victory || store.state.defeat));
  // Sieg kann über zwei Wege erreicht sein (Kern zerstört ODER alle Gegner besiegt) -
  // die Meldung muss den tatsächlich erreichten Weg zeigen, nicht nur "gibt es einen Kern".
  // Großes GAME OVER mit Ergebnis. Der Grund wird beim Kampfende gespeichert (endReason),
  // nicht aus dem Spielstand zurückgerechnet - so stimmt er auch, wenn mehrere Ziele zugleich zutreffen.
  const reasons = {
    enemies: "All enemies are dead",
    cores: store.state.cores.length > 1 ? "All cores entered" : "Core entered",
    heroes: "All heroes are dead"
  };
  if (overlay) overlay.innerHTML = `<div class="battle-overlay-box ${store.state.victory ? "win" : "lose"}"><div class="go-title">GAME OVER</div><div class="go-result">${store.state.victory ? "VICTORY" : "DEFEAT"}</div><div class="go-reason">${esc(reasons[store.state.endReason] || "")}</div><button data-action="restore-battle">Reset battle</button></div>`;
}
// Aktionsbuttons nur aktivieren, wenn die aktive Einheit die Aktion wirklich ausführen kann
function updateActionButtons() {
  const u = getCurrentUnit(), over = store.state.victory || store.state.defeat;
  const canAct = !!u && !over && !isAiTurn() && u.ap >= 1 && !hasStatus(u, "stunned") && !hasStatus(u, "knocked_down");
  document.querySelectorAll(".action-btn[data-action]").forEach(b => {
    const a = b.dataset.action;
    if (a === "end-turn") { b.disabled = !u || over || isAiTurn(); return; }
    b.disabled = !canAct || (a === "ability" && (u.abilityType || "none") === "none");
    b.classList.toggle("active", store.state.mode === a);
  });
}
function renderUnitForm(u, isNew) {
  const numberField = (id, label, value) => `<label class="formlabel">${label}<input class="input" id="unit-${id}" type="number" value="${Number(value || 0)}"></label>`;
  return `${isNew ? '<div class="small">New unit – not saved yet. Click a free tile on the map to place it there.</div>' : '<div class="small">Tip: drag the unit with the mouse onto a free tile to move it.</div>'}
  <label class="formlabel">Name<input class="input" id="unit-name" value="${esc(u.name)}"></label>
  <div class="two"><label class="formlabel">Short icon<input class="input" id="unit-short" value="${esc(u.short)}"></label><label class="formlabel">Color<input class="input" id="unit-color" type="color" value="${safeColor(u.color)}"></label></div>
  <label class="formlabel">Class<input class="input" id="unit-class" value="${esc(u.className)}"></label>
  <label class="formlabel">Team<select class="input" id="unit-team"><option value="hero" ${u.team === "hero" ? "selected" : ""}>Hero</option><option value="enemy" ${u.team === "enemy" ? "selected" : ""}>Enemy</option></select></label>
  <div class="preview" id="unit-preview" style="${previewStyle(u.image)}"></div><label class="upload">Upload unit image<input class="file" id="unit-image" type="file" accept="image/*"></label>
  <div class="two">
  ${numberField("maxhp", "Max HP", u.maxHp ?? u.hp)}
  ${["attack", "defense", "movement", "range", "abilityRange", "damage", "heal", "knockback", "stability", "trapDamage"].map(k => numberField(k, k.replace(/([A-Z])/g, " $1").toLowerCase(), u[k] ?? (k === "abilityRange" ? u.range : 0))).join("")}</div>
  ${isNew ? "" : `<div class="small">Current HP: ${u.hp}/${u.maxHp} (kept when saving, unless Max HP drops below it).</div>`}
  <label class="check"><input id="unit-flying" type="checkbox" ${u.flying ? "checked" : ""}> Flying</label>
  <label class="formlabel">Special ability<select class="input" id="unit-ability">${Object.entries(ABILITIES).map(([k, v]) => `<option value="${k}" ${u.abilityType === k ? "selected" : ""}>${v.label}</option>`).join("")}</select></label>
  <label class="formlabel">Special ability name<input class="input" id="unit-ability-name" value="${esc(u.abilityName)}"></label>
  <div class="two"><label class="formlabel">X<input class="input" id="unit-x" type="number" min="0" max="${COLS - 1}" value="${u.x}"></label><label class="formlabel">Y<input class="input" id="unit-y" type="number" min="0" max="${ROWS - 1}" value="${u.y}"></label></div>
  <div class="two"><button class="success wide" id="save-unit-btn">${isNew ? "Create unit" : "Save changes"}</button><button class="wide" id="cancel-unit-btn">Cancel</button></div>
  ${isNew ? "" : '<button class="warning wide" id="delete-unit-btn">Remove unit</button>'}`;
}
function renderTerrainForm(x, y) {
  const c = getCell(store.board, x, y); if (!c) return "";
  const core = coreAt(x, y);
  return `<div class="small">Tile ${coordLabel(x, y)} (x ${x}, y ${y})${core ? ` · ${esc(core.name)}` : ""}</div><label class="formlabel">Terrain type<select class="input" id="terrain-type">${terrainTools.map(t => `<option value="${t}" ${c.type === t ? "selected" : ""}>${DEFAULT_TERRAIN[t].label}</option>`).join("")}</select></label>
  <div class="two"><label class="formlabel">Cover<input class="input" id="terrain-cover" type="number" min="0" max="9" value="${c.cover || 0}"></label><label class="formlabel">Walkable<select class="input" id="terrain-walk"><option value="1" ${c.walk ? "selected" : ""}>Yes</option><option value="0" ${!c.walk ? "selected" : ""}>No</option></select></label></div>
  <label class="check"><input id="terrain-los" type="checkbox" ${c.los ? "checked" : ""}> Blocks line of sight</label>
  <div class="preview" id="terrain-preview" style="${previewStyle(c.image)}"></div><label class="upload">Upload terrain image<input class="file" id="terrain-image" type="file" accept="image/*"></label>
  <button class="success wide" id="save-terrain-btn">Save terrain</button>`;
}
function renderEditorScreen() {
  document.getElementById("battle-screen")?.classList.add("hidden"); document.getElementById("editor-screen")?.classList.remove("hidden");
  renderBoard(document.getElementById("editor-board"));
  const list = document.getElementById("unit-list");
  if (list) list.innerHTML = store.state.units.map(u => `<button class="unit-item ${(!store.state.editorDraft?.isNew && store.state.editorDraft?.unit.id === u.id) ? "selected-item" : ""}" data-unit-id="${esc(u.id)}"><span>${esc(u.name)}</span><small>${u.team === "hero" ? "Hero" : "Enemy"}</small></button>`).join("") || '<div class="small">No units.</div>';
  const form = document.getElementById("unit-form");
  form.innerHTML = store.state.editorDraft ? renderUnitForm(store.state.editorDraft.unit, store.state.editorDraft.isNew) : store.state.editorTerrain ? renderTerrainForm(store.state.editorTerrain.x, store.state.editorTerrain.y) : '<div class="small">Select a unit or click a tile in the terrain editor.</div>';
  document.querySelectorAll("[data-tool]").forEach(b => b.classList.toggle("active", b.dataset.tool === store.state.tool));
  const nt = document.getElementById("editor-notice");
  if (nt) { nt.textContent = store.state.notice || ""; nt.classList.toggle("hidden", !store.state.notice); }
  const tt = document.getElementById("template-tools");
  if (tt) tt.innerHTML = store.state.tool === "unit" ? `<label class="formlabel">Template for new unit</label><div class="editor-tools"><button data-template="" class="${store.state.editorSelected ? "" : "active"}">New unit</button>${Object.values(templates).map(t => `<button data-template="${t.id}" class="${store.state.editorSelected === t.id ? "active" : ""}">${esc(t.name)}</button>`).join("")}</div>` : "";
}
const IMPACT_WORDS = ["BANG!", "POW!", "WHAM!", "CRASH!", "BOOM!", "ZAP!", "THUD!"];
// Comic-Treffer-Effekt (Sprechblase + Hit-Flash) über der getroffenen Kachel. Läuft auf der
// eigenen #fx-layer-Ebene (siehe CSS-Kommentar dort) und räumt sich über die CSS-Animation
// selbst ab - unabhängig vom nächsten renderBoard()-Aufruf, der direkt danach folgen kann.
// Nur bei tatsächlichen Treffern aufrufen, nie bei Fehlschlägen, Heilung oder Fallen legen.
export function playImpactFX(x, y) {
  const layer = document.getElementById("fx-layer");
  const board = document.getElementById("board");
  const tile = board?.children[y * COLS + x];
  if (!layer || !board || !tile) return;
  const left = board.offsetLeft + tile.offsetLeft, top = board.offsetTop + tile.offsetTop;
  const w = tile.offsetWidth, h = tile.offsetHeight;

  const flash = document.createElement("div");
  flash.className = "fx-flash";
  Object.assign(flash.style, { left: `${left}px`, top: `${top}px`, width: `${w}px`, height: `${h}px` });
  layer.appendChild(flash);
  setTimeout(() => flash.remove(), 500);

  const bubble = document.createElement("div");
  bubble.className = "fx-bubble";
  bubble.textContent = IMPACT_WORDS[Math.floor(Math.random() * IMPACT_WORDS.length)];
  Object.assign(bubble.style, { left: `${left + w / 2}px`, top: `${top}px` });
  layer.appendChild(bubble);
  setTimeout(() => bubble.remove(), 850);
}
export function render() {
  setText("screen-status", store.state.screen === "battle" ? `Battle – Round ${store.state.round}${store.state.victory ? " · Victory" : store.state.defeat ? " · Defeat" : ""}` : "Map editor");
  store.state.screen === "battle" ? renderBattleScreen() : renderEditorScreen();
  renderStatusOverview();
  const aiBtn = document.getElementById("ai-toggle-btn");
  if (aiBtn) { aiBtn.textContent = `Enemy AI: ${store.aiEnabled ? "ON" : "OFF"}`; aiBtn.classList.toggle("success", !!store.aiEnabled); }
  document.getElementById("abort-button")?.classList.toggle("hidden", store.state.screen !== "battle");
  document.getElementById("battle-button")?.classList.toggle("primary", store.state.screen === "battle");
  document.getElementById("editor-button")?.classList.toggle("primary", store.state.screen === "editor");
}
