import { MAP_STORAGE_KEY, LEGACY_MAP_STORAGE_KEYS, ROWS, COLS, EXTRA_COLS } from "./state.js";
import { makeTerrain } from "./board.js";

export function saveMap(data) {
  localStorage.setItem(MAP_STORAGE_KEY, JSON.stringify(data));
}

// Liefert die gespeicherte Karte oder null, wenn nichts (Brauchbares) gespeichert ist.
// Beschädigte Daten führen nicht mehr zu einem Absturz.
// Der Storage-Key trägt die Versionsnummer der Kartendaten (aktuell v4, cores-Liste statt
// einzelnem core). Ist unter dem aktuellen Key noch nichts gespeichert, wird einmalig unter
// den alten Keys nachgeschaut und - falls gefunden - automatisch übernommen (loadEditableMap
// normalisiert das alte Format ohnehin schon beim Laden).
export function loadMap() {
  try {
    let raw = localStorage.getItem(MAP_STORAGE_KEY);
    if (!raw) {
      for (const legacyKey of LEGACY_MAP_STORAGE_KEYS) {
        const legacy = localStorage.getItem(legacyKey);
        if (legacy) { raw = legacy; localStorage.setItem(MAP_STORAGE_KEY, legacy); break; }
      }
    }
    if (!raw) return null;
    const data = JSON.parse(raw);
    const rowsOk = width => data && Array.isArray(data.board) && data.board.length === ROWS
      && data.board.every(row => Array.isArray(row) && row.length === width);
    if (rowsOk(COLS)) return data;
    if (rowsOk(ROWS)) return migrateSquareMap(data); // alte quadratische Karte -> automatisch verbreitern
    return { invalid: true };
  } catch {
    return { invalid: true };
  }
}
// Alte, quadratische Karten (ROWS x ROWS) bekommen links und rechts je EXTRA_COLS Bodenspalten.
// Einheiten und Cores wandern um EXTRA_COLS nach rechts. Die bisherigen Randwände links/rechts (reine
// Wandfelder ohne Bild) werden zu Boden, damit die neuen Spalten auch erreichbar sind; die neue
// Außenkante der Karte wird wieder mit Wänden umrandet.
export function migrateSquareMap(data) {
  const last = ROWS - 1, wall = () => makeTerrain("wall");
  const board = data.board.map((row, y) => {
    const mid = row.map((c, x) => (x === 0 || x === last) && y > 0 && y < last && c?.type === "wall" && !c.image ? makeTerrain("floor") : c);
    const pad = () => Array.from({ length: EXTRA_COLS }, () => (y === 0 || y === last ? wall() : makeTerrain("floor")));
    const full = [...pad(), ...mid, ...pad()];
    full[0] = wall(); full[COLS - 1] = wall();
    return full;
  });
  const shift = list => (Array.isArray(list) ? list : []).map(o => ({ ...o, x: Number(o?.x) + EXTRA_COLS }));
  const out = { ...data, board, units: shift(data.units), traps: [], cores: shift(data.cores) };
  if (data.core) out.core = { ...data.core, x: Number(data.core.x) + EXTRA_COLS };
  return out;
}
export function clone(value) {
  // structuredClone ist seit 2022 in allen modernen Browsern/Node verfügbar und
  // schneller als der JSON-Roundtrip; Fallback nur für sehr alte Umgebungen.
  // Für unsere Daten (Zahlen/Strings/Arrays/Objekte, Bilder als data:-URL-Strings)
  // liefern beide Varianten identische Ergebnisse.
  return typeof structuredClone === "function" ? structuredClone(value) : JSON.parse(JSON.stringify(value));
}
