import { ROWS, COLS, ABILITIES, STATUS } from "./state.js";

// Alte, vor der Umstellung auf Englisch gespeicherte Karten enthalten deutsche Standardtexte.
// Nur genau diese Standardtexte werden übersetzt; selbst vergebene Namen bleiben unverändert.
const LEGACY_DE = {
  "Keine": "None", "Betäuben": "Stun", "Markieren": "Mark", "Heilen": "Heal", "Power-Schlag": "Power Strike", "Heilstrahl": "Healing Beam",
  "Nahkampf / Tank": "Melee / Tank", "Fernkampf / Taktiker": "Ranged / Tactician", "Heiler / Fliegend": "Healer / Flying",
  "Spionin / Fallen": "Spy / Traps", "Fernkampf / Fliegend": "Ranged / Flying", "Schwerer Tank": "Heavy Tank", "Eigene Einheit": "Custom unit",
  "Sicherheitsdrohne 1": "Security Drone 1", "Sicherheitsdrohne 2": "Security Drone 2"
};
function legacyText(value) {
  const text = typeof value === "string" ? value : "";
  return LEGACY_DE[text] ?? text.replace(/^Neue Figur\b/, "New unit");
}

export const DEFAULT_COLOR = "#4daeff";
// Nur #rrggbb ist erlaubt (das ist auch das einzige Format des <input type="color">).
// Alles andere - auch manipulierte Werte aus einer gespeicherten Karte - fällt auf die Standardfarbe zurück,
// damit nie beliebiger Text in HTML-Attribute oder Styles gelangt.
export function safeColor(value) {
  return /^#[0-9a-f]{6}$/i.test(String(value || "")) ? String(value) : DEFAULT_COLOR;
}
// Ganzzahl innerhalb [min, max]; bei ungültigem Wert (NaN, Text ...) der Fallback.
function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}
function safeStatuses(list) {
  return (Array.isArray(list) ? list : [])
    .filter(s => s && Object.hasOwn(STATUS, s.id) && Number.isFinite(Number(s.remaining)))
    .map(s => ({ id: s.id, remaining: clampInt(s.remaining, 0, 99, 1) }));
}

export function makeUnit(template, overrides = {}) {
  const unit = { ...template, ...overrides };
  const maxHp = clampInt(unit.maxHp ?? unit.hp, 1, 9999, 100);
  const movement = clampInt(unit.movement, 0, 30, 4);
  return {
    // Nur generieren, wenn wirklich KEINE id vorhanden ist. createCustomUnit() übergibt
    // bereits eine fertige id - die darf hier nicht nochmal überschrieben werden.
    // (Vorher: Prüfung auf "enthält einen Bindestrich" statt auf "ist vorhanden" - dadurch
    // bekamen die Start-Vorlagen wie "powerkim" bei jedem loadScenario() eine neue Zufalls-id.)
    id: typeof unit.id === "string" && unit.id ? unit.id : `unit-${Math.random().toString(36).slice(2, 8)}`,
    name: legacyText(unit.name) || "New unit",
    short: unit.short || "?",
    // Alle Zahlenwerte werden auf sinnvolle Bereiche begrenzt (Schutz vor kaputten/manipulierten Karten).
    team: unit.team === "enemy" ? "enemy" : "hero",
    className: legacyText(unit.className) || "Custom unit",
    x: clampInt(unit.x, 0, COLS - 1, 0),
    y: clampInt(unit.y, 0, ROWS - 1, 0),
    hp: clampInt(unit.hp ?? maxHp, 0, maxHp, maxHp),
    maxHp,
    attack: clampInt(unit.attack, 0, 999, 10),
    defense: clampInt(unit.defense, 0, 999, 5),
    movement,
    range: clampInt(unit.range, 0, COLS, 1),
    // Reichweite der Spezialfähigkeit; fehlt sie (alte Karten/Vorlagen), gilt die Angriffsreichweite.
    abilityRange: clampInt(unit.abilityRange ?? unit.range, 0, COLS, 1),
    damage: clampInt(unit.damage, 0, 9999, 10),
    heal: clampInt(unit.heal, 0, 9999, 0),
    knockback: clampInt(unit.knockback, 0, COLS, 0),
    stability: clampInt(unit.stability, 0, 999, 10),
    trapDamage: clampInt(unit.trapDamage, 0, 9999, 30),
    abilityType: Object.hasOwn(ABILITIES, unit.abilityType) ? unit.abilityType : "none",
    abilityName: legacyText(unit.abilityName) || "None",
    flying: !!unit.flying,
    color: safeColor(unit.color),
    image: unit.image || "",
    alive: unit.alive !== false,
    inBattle: unit.inBattle !== false,
    ap: clampInt(unit.ap, 0, 9, 2),
    moveLeft: clampInt(unit.moveLeft ?? movement, 0, 30, movement),
    statuses: safeStatuses(unit.statuses)
  };
}

export function isBattleUnit(unit) {
  return !!unit && unit.alive && unit.inBattle !== false;
}

export function statusIcons(unit, statuses) {
  return (unit?.statuses || []).map(item => statuses[item.id]?.icon || "?").join("");
}

// Liefert den nächsten freien Namen mit Nummer: "New unit 1", "New unit 2", ...
// Eine vorhandene Einheit ohne Nummer ("Powerkim") zählt als Nr. 1, das nächste wird "Powerkim 2".
// Es wird immer die höchste vorhandene Nummer + 1 vergeben, damit nach dem Löschen
// keine doppelten Namen entstehen.
export function nextNumberedName(units, baseName = "New unit") {
  const base = String(baseName || "").replace(/\s+\d+$/, "").trim() || "New unit";
  const escaped = base.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pattern = new RegExp(`^${escaped}(?: (\\d+))?$`);
  let max = 0;
  for (const u of units || []) {
    const m = pattern.exec(u?.name || "");
    if (m) max = Math.max(max, m[1] ? Number(m[1]) : 1);
  }
  return { name: `${base} ${max + 1}`, number: max + 1 };
}

export function createCustomUnit(id = `custom-${Math.random().toString(36).slice(2,8)}`) {
  return makeUnit({
    id, name: "New unit", short: "N", team: "hero", className: "Custom unit",
    x: 3, y: 3, hp: 100, maxHp: 100, attack: 10, defense: 5,
    movement: 4, range: 1, damage: 12, heal: 0, knockback: 0, stability: 10,
    abilityType: "none", abilityName: "None", color: "#4daeff", image: ""
  });
}
