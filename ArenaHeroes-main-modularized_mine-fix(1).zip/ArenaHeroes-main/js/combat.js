import { isDiagonalCornerBlocked, isPassable } from "./board.js";

export function reachable(board, units, unit, getCell) {
  const result = [];
  const max = Math.max(0, Number(unit.moveLeft ?? unit.movement ?? 0));
  const seen = new Map([[`${unit.x},${unit.y}`, 0]]);
  const queue = [{ x: unit.x, y: unit.y, d: 0 }];
  const dirs = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
  const occupied = (x, y) => units.some(u => u.alive && u.x === x && u.y === y && u.id !== unit.id);

  while (queue.length) {
    const current = queue.shift();
    if (current.d >= max) continue;
    for (const [dx, dy] of dirs) {
      const x = current.x + dx, y = current.y + dy, d = current.d + 1;
      const key = `${x},${y}`, cell = getCell(board, x, y);
      if (d > max || seen.has(key) || !isPassable(cell, unit) || occupied(x,y)) continue;
      if (isDiagonalCornerBlocked(board, current, {x,y}, unit)) continue;
      seen.set(key, d);
      queue.push({x,y,d});
      result.push({x,y,d});
    }
  }
  return result;
}

export function applyDamage(target, amount, defense = 0) {
  const value = Math.max(1, Math.round(Number(amount || 0) - Number(defense || 0)));
  target.hp = Math.max(0, Number(target.hp || 0) - value);
  if (target.hp <= 0) {
    target.hp = 0;
    target.alive = false;
    target.inBattle = false;
    target.ap = 0;
    target.moveLeft = 0;
  }
  return value;
}

// Malus auf den Trefferwurf von Spezialfähigkeiten (Betäuben, Markieren, Push, Pull).
// Jeder Punkt = 5 Prozentpunkte Trefferchance, 5 Punkte = -25 Prozentpunkte. Hier zentral einstellbar.
export const ABILITY_HIT_MALUS = 5;

// Trefferchance (0..1) für die Anzeige/KI: Anteil der d20-Würfe, die treffen.
export function hitChance(attacker, defense, malus = 0) {
  let hits = 0;
  for (let roll = 1; roll <= 20; roll++) if (roll + Number(attacker.attack || 0) - Number(defense || 0) - malus >= 11) hits++;
  return hits / 20;
}

export function rollHit(attacker, _defender, defense, malus = 0) {
  // d20-System: bei Gleichstand (Angriff == Verteidigung) 50% Trefferchance,
  // jeder Punkt Differenz verschiebt das um 5 Prozentpunkte. Ab +-10 Differenz
  // ist der Ausgang rechnerisch sicher (Treffer bzw. Fehlschlag garantiert).
  // Vorher: attack + [0..5] - defense > 0, d.h. schon bei Gleichstand 83%
  // Trefferchance, und ab attack > defense bereits garantiert 100% Treffer
  // unabhängig davon, wie groß der Unterschied war - Verteidigung hatte damit
  // kaum Wirkung, sobald der Angreifer nur leicht überlegen war.
  const roll = Math.floor(Math.random() * 20) + 1;
  return roll + Number(attacker.attack || 0) - Number(defense || 0) - Number(malus || 0) >= 11;
}
