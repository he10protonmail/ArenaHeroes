// Kartenmaße: ROWS = Höhe, COLS = Breite. Die Karte ist breiter als hoch: links und rechts liegen je
// EXTRA_COLS zusätzliche Spalten (Kachelgröße bleibt gleich). Alte, quadratische 20x20-Karten werden
// beim Laden automatisch mittig eingepasst (siehe storage.js).
export const ROWS = 20;
export const EXTRA_COLS = 4;
export const COLS = ROWS + 2 * EXTRA_COLS;
export const MAP_STORAGE_KEY = "arena-heroes-map-v4";
export const LEGACY_MAP_STORAGE_KEYS = ["arena-heroes-map-v3"];

export const ABILITIES = Object.freeze({
  none: { label: "None" },
  stun: { label: "Stun" },
  mark: { label: "Mark" },
  heal: { label: "Heal" },
  trap: { label: "Mine" },
  push: { label: "Push" },
  pull: { label: "Pull" }
});

export const STATUS = Object.freeze({
  burning: { label: "Burning", icon: "🔥", duration: 2 },
  stunned: { label: "Stunned", icon: "⚡", duration: 1 },
  slowed: { label: "Slowed", icon: "❄", duration: 2 },
  marked: { label: "Marked", icon: "🎯", duration: 1 },
  knocked_down: { label: "Knocked down", icon: "💫", duration: 1 },
  shielded: { label: "Shielded", icon: "🛡", duration: 1 }
});

export function createState() {
  return {
    screen: "battle",
    round: 1,
    units: [],
    selected: null,
    turnOrder: [],
    turnIndex: 0,
    mode: null,
    highlight: [],
    log: [],
    victory: false,
    defeat: false,
    // Cores: { name, x, y, hp, maxHp, entered } - mehrere möglich ("Core 1", "Core 2" ...)
    cores: [],
    // Grund für das Kampfende: "enemies" | "cores" | "heroes" (null solange der Kampf läuft)
    endReason: null,
    tool: "select",
    editorSelected: null,
    editorTerrain: null,
    formTarget: null,
    // editorDraft hält die Arbeitskopie der Einheit, die gerade im Formular
    // bearbeitet wird. Erst beim Speichern wird sie in state.units übernommen
    // (neu) bzw. in die bestehende Einheit gemergt (Bearbeiten). Solange der
    // Draft existiert, ist state.units unverändert – Abbrechen ist damit
    // immer verlustfrei möglich.
    // Form: { isNew: boolean, unit: {...Einheitendaten inkl. id} }
    editorDraft: null,
    traps: [],
    battleSnapshot: null,
    // battleDirty: im laufenden Kampf wurde bereits gehandelt (für die Rückfrage beim Wechsel in den Editor)
    battleDirty: false,
    // notice: kurze Rückmeldung im Editor (der Kampf-Log ist dort nicht sichtbar)
    notice: ""
  };
}
