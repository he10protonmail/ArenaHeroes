import { ROWS, COLS, ABILITIES } from "./state.js";
import { buildPreset } from "./presets.js";
import { getCell, makeTerrain, isPassable } from "./board.js";
import { makeUnit, createCustomUnit, nextNumberedName } from "./units.js";
import { templates, terrainTools } from "./config.js";
import { saveMap as persistMap, loadMap as readMap, clone } from "./storage.js";
import { store, notify, resetBoard } from "./store.js";
import { render } from "./render.js";
import { atAny, placementError, coreAt } from "./selectors.js";

// Cores: mehrere möglich, Position/HP/Name stehen in store.state.cores. Jeder neu
// gesetzte Kern bekommt automatisch die nächste freie Nummer ("Core 1", "Core 2" ...).
export function placeCore(x, y) {
  if (coreAt(x, y)) return; // hier steht schon ein Kern - nicht doppelt anlegen
  const c = getCell(store.board, x, y); Object.assign(c, makeTerrain("core", c.image));
  const { name } = nextNumberedName(store.state.cores, "Core");
  store.state.cores.push({ name, x, y, hp: 100, maxHp: 100, entered: false });
}
export function removeCoreAt(x, y) { store.state.cores = store.state.cores.filter(c => !(c.x === x && c.y === y)); }

// --- Einheiten-Editor: Bearbeiten (bestehend) und Anlegen (neu) sind bewusst
// getrennte Pfade. Beide arbeiten auf store.state.editorDraft, einer Arbeitskopie,
// die store.state.units erst beim Speichern verändert. So bleibt "Abbrechen" immer
// verlustfrei, und eine neue Einheit landet nie unvollständig/ungewollt auf
// der Karte, nur weil man den Editor verlassen hat.
function findFreeEditorCell() {
  for (let y = 1; y < ROWS - 1; y++) for (let x = 1; x < COLS - 1; x++) if (!atAny(x, y) && getCell(store.board, x, y)?.walk) return { x, y };
  return { x: 0, y: 0 };
}
export function startEditUnit(unit) {
  store.state.editorDraft = { isNew: false, unit: clone(unit) };
  store.state.formTarget = unit.id;
  store.state.editorTerrain = null;
}
export function startNewUnitDraft(overrides = {}) {
  const free = findFreeEditorCell();
  const unit = createCustomUnit();
  const freshId = unit.id; // vor dem Überschreiben merken
  Object.assign(unit, { x: free.x, y: free.y }, overrides);
  // BUGFIX: Eine Vorlage (overrides) bringt ihre eigene id mit (z.B. "powerkim"). Ohne
  // diese Zeile würde eine neu erstellte Figur aus der Powerkim-Vorlage exakt dieselbe id
  // wie der Original-Powerkim bekommen -> zwei Einheiten mit identischer id, Auswahl/Löschen/
  // Zielsuche können dann die falsche Figur treffen. Die frisch generierte id gewinnt immer.
  unit.id = freshId;
  // Neue Einheiten werden standardmäßig durchnummeriert (Neue Figur 1, 2, 3 ...).
  const numbered = nextNumberedName(store.state.units, unit.name);
  unit.name = numbered.name;
  if (!overrides.short) unit.short = String(numbered.number);
  store.state.editorDraft = { isNew: true, unit };
  store.state.formTarget = null;
  store.state.editorTerrain = null;
}
export function cancelUnitDraft() {
  store.state.editorDraft = null;
  store.state.formTarget = null;
  render();
}
function readUnitFormValues(current) {
  const val = id => document.getElementById(id)?.value;
  const num = (id, fallback) => { const n = Number(val(id)); return Number.isFinite(n) ? n : fallback; };
  const abilityType = val("unit-ability") || current.abilityType || "none";
  return {
    name: val("unit-name") || current.name,
    short: val("unit-short") || current.short,
    color: val("unit-color") || current.color,
    className: val("unit-class") || current.className,
    team: val("unit-team") || current.team,
    maxHp: Math.max(1, num("unit-maxhp", current.maxHp ?? current.hp)),
    attack: Math.max(0, num("unit-attack", current.attack)),
    defense: Math.max(0, num("unit-defense", current.defense)),
    movement: Math.max(0, num("unit-movement", current.movement)),
    range: Math.max(0, num("unit-range", current.range)),
    abilityRange: Math.max(0, num("unit-abilityRange", current.abilityRange ?? current.range)),
    damage: Math.max(0, num("unit-damage", current.damage)),
    heal: Math.max(0, num("unit-heal", current.heal)),
    knockback: Math.max(0, num("unit-knockback", current.knockback)),
    stability: Math.max(0, num("unit-stability", current.stability)),
    trapDamage: Math.max(0, num("unit-trapDamage", current.trapDamage)),
    flying: !!document.getElementById("unit-flying")?.checked,
    abilityType,
    abilityName: val("unit-ability-name") || ABILITIES[abilityType]?.label || "None",
    x: Math.max(0, Math.min(COLS - 1, num("unit-x", current.x))),
    y: Math.max(0, Math.min(ROWS - 1, num("unit-y", current.y)))
  };
}
export async function saveUnitDraft() {
  if (!store.state.editorDraft) return;
  const { isNew, unit } = store.state.editorDraft;
  const values = readUnitFormValues(unit);
  const file = document.getElementById("unit-image")?.files?.[0];
  const image = file ? await readUnitImage(file) : unit.image;

  if (isNew) {
    const err = placementError({ flying: values.flying }, values.x, values.y);
    if (err) { notify(`${err} Unit not created.`); render(); return; }
    const created = makeUnit({ ...unit, ...values, image, hp: values.maxHp });
    store.state.units.push(created);
    store.state.editorDraft = null;
    store.state.formTarget = created.id;
    notify(`${created.name} was created.`);
  } else {
    const existing = store.state.units.find(u => u.id === unit.id);
    if (!existing) { store.state.editorDraft = null; render(); return; }
    const moved = values.x !== existing.x || values.y !== existing.y;
    if (moved) {
      const err = placementError({ flying: values.flying }, values.x, values.y, existing.id);
      if (err) { notify(`${err} Position not changed.`); values.x = existing.x; values.y = existing.y; }
    }
    // Bewusst KEIN Vollheilen beim Bearbeiten: aktuelle HP bleiben erhalten
    // und werden nur auf die neue Max-HP begrenzt, falls diese gesenkt wurde.
    const hp = Math.min(existing.hp, values.maxHp);
    Object.assign(existing, makeUnit({ ...existing, ...values, image, id: existing.id, hp }));
    store.state.editorDraft = null;
    notify(`${existing.name} was updated.`);
  }
  render();
}
export function deleteUnit(id) {
  store.state.units = store.state.units.filter(u => u.id !== id);
  if (store.state.formTarget === id) store.state.formTarget = null;
  if (store.state.editorDraft && !store.state.editorDraft.isNew && store.state.editorDraft.unit.id === id) store.state.editorDraft = null;
  render();
}
export async function saveTerrain() {
  const p = store.state.editorTerrain; if (!p) return; const c = getCell(store.board, p.x, p.y); if (!c) return;
  const type = document.getElementById("terrain-type").value;
  const file = document.getElementById("terrain-image")?.files?.[0];
  const image = file ? await readUnitImage(file, 128) : c.image;
  const next = {
    ...makeTerrain(type, image),
    cover: Number(document.getElementById("terrain-cover").value || 0),
    walk: document.getElementById("terrain-walk").value === "1",
    los: !!document.getElementById("terrain-los").checked
  };
  const occ = atAny(p.x, p.y);
  if (occ && !isPassable(next, occ)) { notify(`"${occ.name}" is standing on this tile – move the unit first.`); render(); return; }
  if (type === "core") placeCore(p.x, p.y); else removeCoreAt(p.x, p.y);
  Object.assign(c, next);
  store.state.editorTerrain = null; render();
}
export function deleteEditedUnit() {
  if (store.state.editorDraft && !store.state.editorDraft.isNew) deleteUnit(store.state.editorDraft.unit.id);
}
export function createCustomUnitAtEditor() { startNewUnitDraft(); render(); }
// Übernimmt bereits getippte Formularwerte in den Entwurf, bevor das Formular neu gezeichnet wird.
function syncDraftFromForm() {
  if (!store.state.editorDraft) return;
  Object.assign(store.state.editorDraft.unit, readUnitFormValues(store.state.editorDraft.unit));
}
// Verschiebt einen Entwurf (neue, noch nicht gespeicherte Einheit) auf das Feld x,y.
function moveDraftTo(x, y) {
  syncDraftFromForm();
  store.state.editorDraft.unit.x = x; store.state.editorDraft.unit.y = y;
}
// Verschiebt eine bestehende Einheit per Drag & Drop im Editor.
export function moveUnitInEditor(id, x, y) {
  const u = store.state.units.find(v => v.id === id); if (!u) return;
  const err = placementError(u, x, y, id);
  if (err) { notify(err); return; }
  const editingThis = store.state.editorDraft && !store.state.editorDraft.isNew && store.state.editorDraft.unit.id === id;
  if (editingThis) syncDraftFromForm();
  u.x = x; u.y = y;
  if (editingThis) { store.state.editorDraft.unit.x = x; store.state.editorDraft.unit.y = y; }
}
export function saveEditableMap() {
  const hint = store.state.editorDraft ? " Note: a unit that has not been saved yet is not included." : "";
  try {
    // Minen gehören zum Kampf, nicht zur Karte -> nicht mitspeichern
    persistMap({ version: 4, board: store.board, units: store.state.units, traps: [], cores: store.state.cores });
    notify("Map saved." + hint);
  } catch (err) { notify("Map could not be saved (storage full?). Reduce image sizes or remove units."); }
  render();
}
export function loadEditableMap() {
  const d = readMap();
  if (!d) { notify("No saved map found."); render(); return; }
  if (d.invalid) { notify("The saved map is damaged or incomplete and was not loaded."); render(); return; }
  applyMapData(d, "Map loaded.");
}
// Eingebaute Vorlage (siehe presets.js) in den Editor laden. Gespeichert wird erst mit "Save map".
export function loadPreset(id) {
  const d = buildPreset(id);
  if (!d) { notify("Unknown preset."); render(); return; }
  applyMapData(d, `Preset loaded: ${d.label}. Not saved yet – use "Save map" to keep it.`);
}
function applyMapData(d, message) {
  store.board = d.board.map(row => row.map(c => ({ ...makeTerrain(c?.type || "floor"), ...c })));
  store.state.units = (Array.isArray(d.units) ? d.units : []).map(u => makeUnit(u));
  store.state.traps = [];
  // Cores: neues Format (cores-Liste) oder altes Format mit einem einzelnen "core".
  // Nur Einträge, die noch auf einem Kern-Feld liegen, werden übernommen; Kern-Felder
  // ohne Eintrag (manuell bearbeitete Datei) bekommen einen, fehlende Namen werden vergeben.
  store.state.cores = [];
  const saved = Array.isArray(d.cores) ? d.cores : (d.core ? [d.core] : []);
  for (const sc of saved) {
    if (getCell(store.board, sc?.x, sc?.y)?.type === "core" && !coreAt(sc.x, sc.y)) {
      store.state.cores.push({ name: String(sc.name || ""), x: sc.x, y: sc.y, hp: Number(sc.hp ?? 100), maxHp: Number(sc.maxHp ?? 100), entered: false });
    }
  }
  for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) if (store.board[y][x].type === "core" && !coreAt(x, y)) store.state.cores.push({ name: "", x, y, hp: 100, maxHp: 100, entered: false });
  for (const c of store.state.cores) if (!c.name) c.name = nextNumberedName(store.state.cores, "Core").name;
  store.state.formTarget = null; store.state.editorTerrain = null; store.state.editorDraft = null;
  notify(message); render();
}
export function clearEditableMap() { resetBoard(); store.state.units = []; store.state.traps = []; store.state.cores = []; store.state.formTarget = null; store.state.editorTerrain = null; store.state.editorDraft = null; notify("Map cleared."); render(); }
export function clickEditorTile(x, y) {
  if (store.state.tool === "select") {
    const u = atAny(x, y);
    if (u) startEditUnit(u);
    else if (store.state.editorDraft?.isNew) { const err = placementError(store.state.editorDraft.unit, x, y); if (err) notify(err); else moveDraftTo(x, y); }
    else { store.state.editorDraft = null; store.state.formTarget = null; store.state.editorTerrain = { x, y }; }
    return;
  }
  if (store.state.tool === "unit") {
    if (store.state.editorDraft?.isNew) { const err = placementError(store.state.editorDraft.unit, x, y); if (err) notify(err); else moveDraftTo(x, y); return; }
    const t = templates[store.state.editorSelected] ? { ...templates[store.state.editorSelected] } : null;
    const err = placementError({ flying: !!t?.flying }, x, y);
    if (err) { notify(err); return; }
    startNewUnitDraft(t ? { ...t, x, y } : { x, y });
    return;
  }
  if (terrainTools.includes(store.state.tool)) {
    const c = getCell(store.board, x, y), next = makeTerrain(store.state.tool, c.image), occ = atAny(x, y);
    if (occ && !isPassable(next, occ)) { notify(`"${occ.name}" is standing on this tile – move the unit first.`); return; }
    if (store.state.tool === "core") placeCore(x, y); else { removeCoreAt(x, y); Object.assign(c, next); }
    store.state.editorTerrain = { x, y }; store.state.formTarget = null; store.state.editorDraft = null;
  }
  if (store.state.tool === "delete") { removeCoreAt(x, y); Object.assign(getCell(store.board, x, y), makeTerrain("floor")); store.state.editorTerrain = null; }
}
function readFile(file) { return new Promise((resolve, reject) => { if (!file) return resolve(""); const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsDataURL(file); }); }
// Unit-Bilder werden mittig quadratisch zugeschnitten und auf 192x192 verkleinert.
// Grund: Handyfotos sind mehrere MB groß und sprengen sonst das localStorage-Limit
// (~5 MB) beim Speichern der Karte. Auf dem Feld wird das Bild ohnehin nur ~46px groß.
export function readUnitImage(file, size = 192) {
  return new Promise((resolve, reject) => {
    if (!file) return resolve("");
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const side = Math.min(img.naturalWidth, img.naturalHeight) || size;
      const c = document.createElement("canvas"); c.width = c.height = size;
      c.getContext("2d").drawImage(img, (img.naturalWidth - side) / 2, (img.naturalHeight - side) / 2, side, side, 0, 0, size, size);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/webp", 0.85));
    };
    img.onerror = () => { URL.revokeObjectURL(url); readFile(file).then(resolve, reject); };
    img.src = url;
  });
}
