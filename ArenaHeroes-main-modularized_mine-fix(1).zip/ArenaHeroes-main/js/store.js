import { createEmptyMap, addBorderWalls } from "./board.js";
import { createState } from "./state.js";

// Alle Module teilen sich dieses eine Objekt statt eigener board/state-Variablen.
// Grund: ES-Module können importierte "let"-Bindings nicht von außen neu zuweisen
// (z.B. board = neueKarte() geht nur im besitzenden Modul). Da mehrere Stellen im
// Spiel (Editor "Karte leeren", Kampf-Reset, Karte laden) das GESAMTE board- bzw.
// state-Objekt ersetzen müssen, kapseln wir beides in store.board / store.state:
// die Objektreferenz (store) bleibt stabil, nur ihre Felder werden neu zugewiesen –
// und das ist für alle importierenden Module sofort sichtbar.
export const store = {
  board: createEmptyMap(),
  state: createState(),
  // Snapshot der Karte/Einheiten zu Kampfbeginn, für "Kampf zurücksetzen"/Editor-Abbruch.
  battleInitial: null,
  // Gegner-KI an/aus. Bewusst nicht in state, damit der Schalter einen Kampf-Reset überlebt.
  aiEnabled: true
};

// Neue, leere Karte mit Außenwänden erzeugen und als aktives Board setzen.
export function resetBoard() {
  store.board = createEmptyMap();
  addBorderWalls(store.board);
  return store.board;
}

// Kurze Rückmeldung setzen (Editor-Meldung oben in der Sidebar, "Karte testen"-Hinweise).
export function notify(msg) {
  store.state.notice = msg;
}
