import { EXTRA_COLS } from "./state.js";
import { parseCoord } from "./board.js";
import { unitStats } from "../unit-stats.js";
// Die Werte der Figuren stehen in ../unit-stats.js (von Hand editierbar). Hier werden daraus die Vorlagen
// für das Standard-Szenario und die Auswahl im Editor-Werkzeug "Einheit" gebaut.
export const templates = Object.fromEntries(Object.entries(unitStats).map(([id, stats]) => {
  const { start, hp, ...rest } = stats;
  let pos = parseCoord(start);
  if (!pos) { console.warn(`unit-stats.js: ungültiges Startfeld "${start}" bei "${id}" - Ersatzfeld wird verwendet.`); pos = { x: EXTRA_COLS + 1, y: 1 }; }
  return [id, { id, ...rest, hp, maxHp: hp, x: pos.x, y: pos.y }];
}));

// Reihenfolge/Auswahl der Geländewerkzeuge im Editor (ohne "select"/"unit"/"delete").
export const terrainTools = ["floor", "wall", "water", "tree", "container", "vehicle", "core"];
