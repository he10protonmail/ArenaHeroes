import { STATUS, ROWS, COLS, EXTRA_COLS, createState } from "./state.js";
import { getCell, lineOfSight, makeTerrain, isPassable, isDiagonalCornerBlocked } from "./board.js";
import { reachable, applyDamage, rollHit, hitChance, ABILITY_HIT_MALUS } from "./combat.js";
import { makeUnit, isBattleUnit } from "./units.js";
import { templates } from "./config.js";
import { clone } from "./storage.js";
import { store, notify } from "./store.js";
import { render, playImpactFX } from "./render.js";
import { getCurrentUnit, at, atAny, dist, hasStatus, effectiveDefense, canEnter, coreAt, isCoreOpen, heroOnCore, isAiTurn, abilityReach } from "./selectors.js";

export function addLog(text) {
  store.state.log.unshift(text);
  store.state.log = store.state.log.slice(0, 24);
}
export function addStatus(e, id, duration = STATUS[id]?.duration || 1) {
  if (!e || !STATUS[id]) return;
  const old = e.statuses.find(s => s.id === id);
  if (old) old.remaining = Math.max(old.remaining, duration); else e.statuses.push({ id, remaining: duration });
  addLog(`${e.name}: ${STATUS[id].label}.`);
}
function resetState() { store.state = createState(); }

export function findCoreCell() {
  // Start der Suche im ursprünglichen Kartenbereich (hinter den zusätzlichen Randspalten links)
  for (let y = 1; y < ROWS - 1; y++) for (let x = EXTRA_COLS + 1; x < COLS - 1; x++) if (!atAny(x, y) && getCell(store.board, x, y)?.walk) return { x, y };
  return { x: Math.floor(COLS / 2), y: Math.floor(ROWS / 2) };
}
export function loadScenario() {
  resetState();
  store.state.units = Object.values(templates).map(t => makeUnit(t));
  const coreCell = findCoreCell();
  store.state.cores = [{ name: "Core 1", x: coreCell.x, y: coreCell.y, hp: 100, maxHp: 100, entered: false }];
  Object.assign(getCell(store.board, coreCell.x, coreCell.y), makeTerrain("core"));
  startRound(); snapshotBattle(); render(); scheduleAI();
}
export function snapshotBattle() {
  store.battleInitial = clone({ board: store.board, units: store.state.units, cores: store.state.cores, traps: store.state.traps });
  store.state.battleSnapshot = store.battleInitial;
}
// Stellt Karte und Einheiten wie zu Kampfbeginn wieder her (ohne neu zu zeichnen).
export function restoreFromSnapshot() {
  if (!store.battleInitial) return;
  store.board = clone(store.battleInitial.board);
  store.state.units = clone(store.battleInitial.units);
  store.state.cores = clone(store.battleInitial.cores);
  store.state.traps = clone(store.battleInitial.traps);
  store.state.victory = false; store.state.defeat = false; store.state.endReason = null; store.state.log = []; store.state.round = 1;
  store.state.mode = null; store.state.highlight = []; store.state.battleDirty = false;
}
export function restoreBattle() { restoreFromSnapshot(); store.state.screen = "battle"; startRound(); render(); scheduleAI(); }
// Kampf aus dem Editor starten: die aktuelle Karte wird zum Kampfbeginn (Snapshot).
export function startBattle() {
  const heroes = store.state.units.filter(u => u.team === "hero"), enemies = store.state.units.filter(u => u.team === "enemy");
  if (!heroes.length) { notify("At least one hero is needed to test."); render(); return; }
  if (!enemies.length && !store.state.cores.length) { notify("At least one enemy or one core is needed to test."); render(); return; }
  store.state.units.forEach(u => { u.statuses = []; });
  store.state.cores.forEach(c => { c.entered = false; });
  store.state.traps = []; store.state.victory = false; store.state.defeat = false; store.state.endReason = null; store.state.log = [];
  store.state.round = 1; store.state.mode = null; store.state.highlight = []; store.state.battleDirty = false;
  store.state.screen = "battle";
  startRound(); snapshotBattle(); render(); scheduleAI();
}
export function openEditor() {
  if (store.state.screen === "battle") {
    if (store.state.battleDirty && !confirm("The running battle will end and the map will be reset to its pre-battle state. Open editor?")) return;
    restoreFromSnapshot();
  }
  store.state.screen = "editor"; render();
}
// Neue Runde: Reihenfolge und Aktionspunkte zurücksetzen. turnIndex steht danach VOR der ersten Einheit.
function beginRound() {
  store.state.turnOrder = store.state.units.filter(isBattleUnit).sort((a, b) => (b.movement || 0) - (a.movement || 0));
  store.state.turnIndex = -1;
  // Das Minimum von 1 fängt nur ab, dass der "slowed"-Status eine an sich bewegliche
  // Einheit auf 0 drückt - eine im Editor bewusst auf movement:0 gestellte Einheit
  // (z.B. ein stationärer Geschützturm) bleibt dagegen wirklich unbeweglich.
  store.state.turnOrder.forEach(u => { u.ap = 2; u.moveLeft = (u.movement || 0) <= 0 ? 0 : Math.max(1, (u.movement || 0) - (hasStatus(u, "slowed") ? 2 : 0)); });
}
// Rückt zur nächsten handlungsfähigen Einheit vor (ggf. in die nächste Runde).
// Gefallene Einheiten werden übersprungen. Betäubte/umgeworfene Einheiten setzen aus und
// zählen dabei ihren Status herunter – sonst würde er nie enden.
function stepToNextUnit() {
  let newRounds = 0;
  while (store.state.turnOrder.length) {
    store.state.turnIndex++;
    if (store.state.turnIndex >= store.state.turnOrder.length) {
      if (++newRounds > 3) return;
      store.state.round++; beginRound(); continue;
    }
    const u = store.state.turnOrder[store.state.turnIndex];
    if (!isBattleUnit(u)) continue;
    if (hasStatus(u, "stunned") || hasStatus(u, "knocked_down")) {
      addLog(`${u.name} skips the turn due to a status effect.`); tickStatuses(u); continue;
    }
    return;
  }
}
function startRound() { aiTurnKey = null; beginRound(); stepToNextUnit(); }
function tickStatuses(u) {
  if (!u) return;
  u.statuses = u.statuses.filter(s => {
    s.remaining--;
    if (s.remaining <= 0) { addLog(`${u.name}: ${STATUS[s.id]?.label || s.id} wears off.`); return false; }
    return true;
  });
}
// Beendet den Kampf und merkt sich den Grund (für die GAME-OVER-Anzeige).
function finishBattle(victory, reason, logText) {
  if (victory) store.state.victory = true; else store.state.defeat = true;
  store.state.endReason = reason;
  store.state.mode = null; store.state.highlight = [];
  addLog(logText);
}
function checkMission() {
  if (store.state.victory || store.state.defeat) return;
  // Cores: Jeder Kern ist über seine normale "walk"-Eigenschaft (Editor:
  // "Begehbar") entweder von Anfang an offen, oder er startet geschlossen mit HP und
  // wird erst begehbar, wenn er wie ein "Schalter" auf 0 HP heruntergekämpft wurde
  // (siehe executeCoreAttack). Reines Zerstören gewinnt nicht - der offene Kern muss
  // von einer Heldeneinheit betreten werden. Ein betretener Kern bleibt "betreten",
  // auch wenn der Held das Feld später wieder verlässt.
  for (const core of store.state.cores) {
    if (!core.entered && isCoreOpen(core) && heroOnCore(core)) { core.entered = true; addLog(`${core.name} entered.`); }
  }
  const allCoresEntered = store.state.cores.length > 0 && store.state.cores.every(c => c.entered);
  // "Alle Feinde tot" zählt nur, wenn die Karte überhaupt Gegner hat - sonst wäre eine
  // Karte nur mit Core(en) sofort nach der ersten Aktion "gewonnen".
  const enemies = store.state.units.filter(u => u.team === "enemy");
  const allEnemiesDead = enemies.length > 0 && enemies.every(u => !u.alive);
  if (allCoresEntered) return finishBattle(true, "cores", store.state.cores.length > 1 ? "Mission accomplished: All cores entered." : "Mission accomplished: Core entered.");
  if (allEnemiesDead) return finishBattle(true, "enemies", "Mission accomplished: All enemies dead.");
  if (!store.state.units.some(u => u.team === "hero" && u.alive)) finishBattle(false, "heroes", "Defeat: All heroes are dead.");
}
function advanceTurn() {
  tickStatuses(getCurrentUnit());
  stepToNextUnit();
  checkMission();
}
export function executeCoreAttack(core) {
  const u = getCurrentUnit();
  // Ein bereits geöffneter (begehbarer) Kern ist kein Angriffsziel mehr - da gibt's
  // nichts mehr zu treffen, nur noch zu betreten.
  if (!core || isCoreOpen(core)) return;
  // Feindliche Einheiten dürfen Cores nicht beschädigen - nur die Helden können den Schalter auslösen.
  if (u?.team === "enemy") return;
  if (!u || u.ap < 1 || dist(u, core) > u.range || !lineOfSight(store.board, u, core)) return;
  const defense = Number(getCell(store.board, core.x, core.y)?.cover || 0);
  // Schaden/Verteidigung-Modell (einheitlich für Angriff, Kern-Angriff UND Fähigkeiten):
  // Verteidigung wirkt immer genau EINMAL, aber an unterschiedlicher Stelle je nach Angriffsart -
  // beide Wege sind bewusst so und keine doppelte Anrechnung:
  //  - Normaler Angriff/Kern-Angriff: kann verfehlen (rollHit), Verteidigung senkt die Trefferchance,
  //    der Schaden bei einem Treffer wird danach NICHT nochmal reduziert (0 an applyDamage).
  //  - Fähigkeiten (Betäuben/Markieren/Push/Pull): würfeln ebenfalls, aber mit Malus (ABILITY_HIT_MALUS),
  //    damit nicht dauerhaft nur mit Spezialangriffen gespielt wird. Heilen und Minen legen würfeln nicht.
  if (rollHit(u, core, defense)) {
    playImpactFX(core.x, core.y);
    const dealt = applyDamage(core, u.damage || u.attack + 5, 0);
    addLog(`${u.name} deals ${dealt} damage to ${core.name}.`);
    if (core.hp <= 0) {
      core.hp = 0;
      // Schalter ausgelöst: Kern wird begehbar, aber NICHT automatisch zum Sieg -
      // eine Heldeneinheit muss ihn danach noch aktiv betreten (siehe checkMission).
      const cell = getCell(store.board, core.x, core.y);
      if (cell && !cell.walk) { Object.assign(cell, { walk: true, los: false, cover: 0 }); addLog(`The switch was triggered - ${core.name} is now walkable.`); }
    }
  } else addLog(`${u.name} misses ${core.name}.`);
  u.ap--; store.state.battleDirty = true; store.state.mode = null; store.state.highlight = []; checkMission(); render();
}
export function executeAttack(target) {
  const u = getCurrentUnit(); if (!u || !target || u.ap < 1 || target.team === u.team || dist(u, target) > u.range || !lineOfSight(store.board, u, target)) return;
  if (rollHit(u, target, effectiveDefense(target))) {
    playImpactFX(target.x, target.y); // vor einem evtl. Knockback, damit die Blase am Trefferort erscheint
    // Siehe Kommentar in executeCoreAttack: Verteidigung wurde bereits beim Trefferwurf
    // berücksichtigt, deshalb hier 0 statt nochmal effectiveDefense(target).
    const dealt = applyDamage(target, u.damage || u.attack + 5, 0); addLog(`${u.name} deals ${dealt} damage to ${target.name}.`); if (target.alive && u.knockback) applyKnockback(target, u, u.knockback);
  } else addLog(`${u.name} misses ${target.name}.`);
  u.ap--; store.state.battleDirty = true; store.state.mode = null; store.state.highlight = []; checkMission(); render();
}
export function executeAbility(target, x, y) {
  const u = getCurrentUnit(); if (!u || u.ap < 1) return;
  if (u.abilityType === "trap") { if (!store.state.highlight.some(p => p.x === x && p.y === y)) return; store.state.traps.push({ x, y, damage: u.trapDamage || 30 }); addLog(`${u.name} lays a mine.`); }
  else if (u.abilityType === "heal") { if (!target || target.team !== u.team || dist(u, target) > abilityReach(u) || !lineOfSight(store.board, u, target)) return; const amount = u.heal || 0; target.hp = Math.min(target.maxHp, target.hp + amount); addLog(`${u.name} heals ${target.name} for ${amount}.`); }
  else {
    // Fähigkeiten würfeln wie normale Angriffe, aber mit starkem Malus. Bei einem Fehlschlag gibt es
    // weder Schaden noch Status noch Rückstoß/Pull - der AP ist trotzdem verbraucht (siehe unten).
    // Verteidigung wirkt wie beim Angriff nur beim Trefferwurf, nicht nochmal auf den Schaden.
    if (!target || target.team === u.team || dist(u, target) > abilityReach(u) || !lineOfSight(store.board, u, target)) return;
    if (!rollHit(u, target, effectiveDefense(target), ABILITY_HIT_MALUS)) {
      addLog(`${u.name} misses ${target.name} with ${u.abilityName || "the ability"}.`);
      u.ap--; store.state.battleDirty = true; store.state.mode = null; store.state.highlight = []; checkMission(); render();
      return;
    }
    playImpactFX(target.x, target.y); // vor evtl. Knockback/Pull, damit die Blase am Trefferort erscheint
    const dealt = applyDamage(target, u.damage || 10, 0); addLog(`${u.name} deals ${dealt} ability damage to ${target.name}.`);
    if (u.abilityType === "stun") addStatus(target, "stunned"); if (u.abilityType === "mark") addStatus(target, "marked");
    // BUGFIX: Rückstoß nutzt jetzt einheitlich den Knockback-Stat der Einheit (wie beim
    // normalen Angriff) statt nur bei abilityType "push" und dort hartcodiert mit 1 Feld.
    // Vorher hatte Powerkims "Power-Schlag" (stun, knockback:3) trotz Knockback-Wert nie
    // Rückstoß ausgelöst, weil nur "push" überhaupt applyKnockback() aufgerufen hat.
    if (u.abilityType !== "pull" && target.alive && u.knockback) applyKnockback(target, u, u.knockback);
    if (u.abilityType === "pull" && target.alive) {
      const dest = pullDestination(u, target);
      if (dest) {
        const moved = Math.max(Math.abs(dest.x - target.x), Math.abs(dest.y - target.y));
        // Schrittweise ziehen: Jede Mine auf dem Weg löst aus (auch wenn das Ziel nicht darauf stehen bleibt).
        // Stirbt das Ziel an einer Mine, endet der Pull sofort.
        const sx = Math.sign(dest.x - target.x), sy = Math.sign(dest.y - target.y);
        let steps = 0;
        while ((target.x !== dest.x || target.y !== dest.y) && target.alive) {
          target.x += sx; target.y += sy; steps++;
          triggerTrap(target);
        }
        addLog(`${target.name} is pulled ${steps} tile${steps === 1 ? "" : "s"} toward ${u.name}.`);
      }
    }
  }
  u.ap--; store.state.battleDirty = true; store.state.mode = null; store.state.highlight = []; checkMission(); render();
}
// Pull (Gegenteil von Knockback): Das Ziel wird Schritt für Schritt zur ziehenden Einheit gezogen, bis es direkt
// neben ihr steht - oder bis ein Feld blockiert ist (Hindernis, andere Einheit, Wasser für Nicht-Flieger).
// Liefert das Zielfeld oder null, wenn gar keine Bewegung möglich ist. Minen auf dem Weg lösen beim Ziehen aus (siehe executeAbility).
function pullDestination(source, target) {
  let x = target.x, y = target.y;
  while (Math.max(Math.abs(source.x - x), Math.abs(source.y - y)) > 1) {
    const nx = x + Math.sign(source.x - x), ny = y + Math.sign(source.y - y);
    if (!canEnter(target, nx, ny, target.id)) break;
    x = nx; y = ny;
  }
  return x !== target.x || y !== target.y ? { x, y } : null;
}
export function clickBattleTile(x, y) {
  const u = getCurrentUnit(), target = at(x, y);
  const coreTarget = coreAt(x, y);
  if (!u || store.state.victory || store.state.defeat || isAiTurn()) return;
  if (store.state.mode === "move") return executeMove(x, y);
  if (store.state.mode === "attack") return coreTarget && u.team !== "enemy" ? executeCoreAttack(coreTarget) : executeAttack(target);
  if (store.state.mode === "ability") return executeAbility(target, x, y);
  if (target?.team === "hero") { store.state.selected = target.id; const i = store.state.turnOrder.findIndex(v => v.id === target.id); if (i >= 0) store.state.turnIndex = i; }
  render();
}
function triggerTrap(unit) {
  const trap = store.state.traps.find(t => t.x === unit.x && t.y === unit.y); if (!trap) return;
  const dealt = applyDamage(unit, trap.damage, effectiveDefense(unit)); store.state.traps = store.state.traps.filter(t => t !== trap);
  addLog(`${unit.name} triggers a mine and takes ${dealt} damage.`);
}
// Schaden beim Anprall an Hindernis/Einheit während eines Knockbacks: 2 Schaden pro
// zurückgelegtem Feld (impact = wievieltes Feld des Knockbacks), reduziert um die
// eigene Stabilität (10 Stabilität = 1 Schaden weniger), aber immer mindestens 1.
function collisionDamage(unit, impact) { return Math.max(1, Math.round(impact * 2 - (unit.stability || 0) / 10)); }
// Ob eine Kollision die Einheit umwirft, hängt von ihrer Stabilität ab (Bulwark mit 40
// Stabilität bleibt öfter stehen als Nyra mit 8). "force" ist die Rückstoßstärke * 10, damit
// sie auf derselben Skala wie die stability-Werte der Einheiten (~8-40) liegt.
// Anmerkung: die exakte Schwelle ist eine Kalibrierung meinerseits, keine feste Spielregel -
// bei Bedarf hier leicht nachjustierbar.
function shouldKnockDown(force, stability) { return force > (stability || 0); }
function applyKnockback(target, source, distance) {
  if (!target?.alive || distance <= 0) return;
  const dx = Math.sign(target.x - source.x), dy = Math.sign(target.y - source.y); if (!dx && !dy) return;
  const force = distance * 10;
  let moved = 0;
  for (let i = 0; i < distance; i++) {
    const nx = target.x + dx, ny = target.y + dy, cell = getCell(store.board, nx, ny);
    const blocker = at(nx, ny);
    if (blocker && blocker.id !== target.id) {
      // BUGFIX: Beide Einheiten nehmen jetzt Kollisionsschaden, nicht nur die zurückgestoßene.
      const dealt = applyDamage(target, collisionDamage(target, i + 1), 0);
      const dealtBlocker = blocker.alive ? applyDamage(blocker, collisionDamage(blocker, i + 1), 0) : 0;
      addLog(`${target.name} slams into ${blocker.name} and takes ${dealt} collision damage${blocker.alive ? ` (${blocker.name}: ${dealtBlocker})` : ""}.`);
      // BUGFIX: Knockdown hing bisher an keiner Bedingung - jetzt entscheidet die Stabilität.
      if (target.alive && shouldKnockDown(force, target.stability)) addStatus(target, "knocked_down");
      if (blocker.alive && shouldKnockDown(force, blocker.stability)) addStatus(blocker, "knocked_down");
      break;
    }
    if (!isPassable(cell, target)) {
      const dealt = applyDamage(target, collisionDamage(target, i + 1), 0);
      addLog(`${target.name} slams into an obstacle and takes ${dealt} collision damage.`);
      if (target.alive && shouldKnockDown(force, target.stability)) addStatus(target, "knocked_down");
      break;
    }
    target.x = nx; target.y = ny; moved++;
    // Mine auf dem Feld, in das die Einheit geschleudert wird: sofort auslösen. Stirbt sie dabei, endet der Rückstoß.
    triggerTrap(target);
    if (!target.alive) break;
  }
  if (moved) addLog(`${target.name} is knocked back ${moved} tile${moved === 1 ? "" : "s"}.`);
}
export function executeMove(x, y) {
  const u = getCurrentUnit(), step = store.state.highlight.find(p => p.x === x && p.y === y); if (!u || !step || u.ap < 1) return;
  u.x = x; u.y = y; u.ap--; u.moveLeft -= step.d; store.state.battleDirty = true; triggerTrap(u); store.state.mode = null; store.state.highlight = []; checkMission(); render();
}
function finishTurn() { if (store.state.victory || store.state.defeat) return; store.state.battleDirty = true; store.state.mode = null; store.state.highlight = []; advanceTurn(); render(); scheduleAI(); }
// "Zug beenden" des Spielers - während die KI am Zug ist, gesperrt.
export function endTurn() { if (isAiTurn()) return; finishTurn(); }

// ===================== Gegner-KI =====================
// Einfache Regeln pro Gegner-Einheit (jede Aktion kostet 1 AP, je Zug 2 AP):
//  1. Heiler: verletzten Verbündeten in Reichweite heilen.
//  2. Held in Reichweite + Sichtlinie: angreifen (schwächster zuerst). Angriffs-Fähigkeiten
//     (Betäuben/Markieren/Push/Pull) werden einmal pro Zug bevorzugt, solange ihre Trefferchance
//     (mit Malus) mindestens 35 % beträgt - sonst greift die Einheit normal an.
//  3. Sonst bewegen: auf ein Feld, von dem aus ein Held angreifbar ist, sonst auf kürzestem
//     Weg (um Hindernisse herum) Richtung nächstem Helden. Minen werden gemieden.
//  4. Nichts mehr möglich / keine AP: Zug beenden.
// Cores greift die KI nie an (siehe executeCoreAttack).
const AI_DELAY = 650; // ms zwischen zwei KI-Aktionen, damit man mitschauen kann
// aiTurnKey = "Runde:Einheiten-id" des laufenden KI-Zugs. Das Merkmal "Fähigkeit schon benutzt" gilt nur für diesen einen Zug
// (früher: nur bei Wechsel der Einheit zurückgesetzt - dann hätte eine einzelne Gegnerfigur ihre Fähigkeit nur einmal im Kampf genutzt).
let aiTimer = null, aiTurnKey = null, aiUsedAbility = false;

export function scheduleAI(delay = AI_DELAY) {
  clearTimeout(aiTimer); aiTimer = null;
  if (isAiTurn()) aiTimer = setTimeout(aiStep, delay);
}
export function setAiEnabled(on) {
  store.aiEnabled = !!on;
  if (!on) { clearTimeout(aiTimer); aiTimer = null; }
  render(); scheduleAI();
}
function seesTarget(u, t) { return dist(u, t) <= u.range && lineOfSight(store.board, u, t); }
function abilityReaches(u, t) { return dist(u, t) <= abilityReach(u) && lineOfSight(store.board, u, t); }

// Wegstrecke (in Feldern) von jedem Feld bis zum nächsten Ziel, Hindernisse umgangen.
function distanceField(unit, targets) {
  const field = Array.from({ length: ROWS }, () => Array(COLS).fill(Infinity));
  const queue = [], dirs = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
  for (const t of targets) { field[t.y][t.x] = 0; queue.push({ x: t.x, y: t.y }); }
  while (queue.length) {
    const c = queue.shift();
    for (const [dx, dy] of dirs) {
      const x = c.x + dx, y = c.y + dy, cell = getCell(store.board, x, y);
      if (!cell || field[y][x] !== Infinity || !isPassable(cell, unit)) continue;
      if (isDiagonalCornerBlocked(store.board, c, { x, y }, unit)) continue;
      field[y][x] = field[c.y][c.x] + 1; queue.push({ x, y });
    }
  }
  return field;
}
function aiChooseMove(u, heroes, options) {
  const field = distanceField(u, heroes), here = field[u.y][u.x];
  let best = null, bestScore = Infinity;
  for (const p of options) {
    const trapPenalty = store.state.traps.some(t => t.x === p.x && t.y === p.y) ? 3 : 0;
    // Ziel von p aus angreifbar: normale Angriffsreichweite, oder - bei Pull-Einheiten - Peitschenreichweite, wenn der Pull gute Chancen hat
    const reach = abilityReach(u), pulls = u.abilityType === "pull";
    const inRange = heroes.filter(h => lineOfSight(store.board, p, h) && (dist(p, h) <= u.range
      || (pulls && dist(p, h) <= reach && hitChance(u, effectiveDefense(h), ABILITY_HIT_MALUS) >= 0.35)));
    let score;
    if (inRange.length) score = -1000 - Math.min(...heroes.map(h => dist(p, h))) + trapPenalty; // Fernkämpfer halten Abstand
    else if (field[p.y][p.x] < here) score = field[p.y][p.x] + trapPenalty;
    else continue;
    if (score < bestScore) { bestScore = score; best = p; }
  }
  return best;
}
// Führt EINE Aktion aus. Gibt false zurück, wenn nichts Sinnvolles mehr zu tun ist.
function aiAct(u) {
  if (!u || !u.alive || u.ap < 1) return false;
  const foes = store.state.units.filter(t => isBattleUnit(t) && t.team !== u.team);
  if (u.abilityType === "heal") {
    const hurt = store.state.units.filter(t => isBattleUnit(t) && t.team === u.team && t.hp < t.maxHp * 0.6 && abilityReaches(u, t))
      .sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0];
    if (hurt) { executeAbility(hurt, hurt.x, hurt.y); return true; }
  }
  if (!foes.length) return false;
  const inRange = foes.filter(t => seesTarget(u, t)).sort((a, b) => a.hp - b.hp);
  // Minenleger: solange kein Held angreifbar ist, einmal pro Zug eine Mine auf das freie Feld in
  // Reichweite legen, das (Wegstrecke) am nächsten an den Helden liegt.
  if (u.abilityType === "trap" && !aiUsedAbility && !inRange.length) {
    const field = distanceField(u, foes), cells = [];
    const reach = abilityReach(u);
    for (let dy = -reach; dy <= reach; dy++) for (let dx = -reach; dx <= reach; dx++) {
      const x = u.x + dx, y = u.y + dy;
      if ((!dx && !dy) || dist(u, { x, y }) > reach || !canEnter(u, x, y) || store.state.traps.some(t => t.x === x && t.y === y)) continue;
      if (Number.isFinite(field[y]?.[x])) cells.push({ x, y, f: field[y][x] });
    }
    if (cells.length) {
      cells.sort((a, b) => a.f - b.f);
      aiUsedAbility = true;
      store.state.mode = "ability"; store.state.highlight = cells;
      executeAbility(null, cells[0].x, cells[0].y);
      return true;
    }
  }
  // Angriffs-Fähigkeit (Betäuben/Markieren/Push/Pull), einmal pro Zug, mit Reichweite der Fähigkeit - aber nur, wenn
  // die Trefferchance (mit Malus) mindestens 35 % beträgt. Pull nur, wenn das Ziel nicht schon daneben steht und sich bewegen lässt.
  const type = u.abilityType;
  if (["stun", "mark", "push", "pull"].includes(type) && !aiUsedAbility) {
    const cand = foes.filter(t => abilityReaches(u, t)).sort((a, b) => a.hp - b.hp).find(t =>
      hitChance(u, effectiveDefense(t), ABILITY_HIT_MALUS) >= 0.35
      && !(type === "stun" && hasStatus(t, "stunned")) && !(type === "mark" && hasStatus(t, "marked"))
      && !(type === "pull" && (dist(u, t) <= 1 || !pullDestination(u, t))));
    if (cand) { aiUsedAbility = true; executeAbility(cand, cand.x, cand.y); return true; }
  }
  if (inRange.length) { executeAttack(inRange[0]); return true; }
  if (u.moveLeft < 1) return false;
  const options = reachable(store.board, store.state.units, u, getCell);
  const step = aiChooseMove(u, foes, options);
  if (!step) return false;
  store.state.mode = "move"; store.state.highlight = options;
  executeMove(step.x, step.y);
  return true;
}
function aiStep() {
  aiTimer = null;
  if (!isAiTurn()) return;
  const u = getCurrentUnit();
  const turnKey = `${store.state.round}:${u.id}`;
  if (turnKey !== aiTurnKey) { aiTurnKey = turnKey; aiUsedAbility = false; }
  const apBefore = u.ap;
  aiAct(u);
  if (store.state.victory || store.state.defeat) return;
  // Nur weitermachen, wenn die Aktion wirklich AP verbraucht hat (schützt vor Endlosschleifen).
  if (u.ap < apBefore) scheduleAI(); else finishTurn();
}
export function activateMode(mode) {
  const u = getCurrentUnit(); if (!u || isAiTurn() || u.ap < 1 || hasStatus(u, "stunned") || hasStatus(u, "knocked_down") || store.state.victory || store.state.defeat) return;
  if (store.state.mode === mode) { store.state.mode = null; store.state.highlight = []; render(); return; }
  if (mode === "ability" && (u.abilityType || "none") === "none") { addLog(`${u.name} has no ability.`); render(); return; }
  store.state.mode = mode;
  if (mode === "move") store.state.highlight = reachable(store.board, store.state.units, u, getCell);
  if (mode === "attack") {
    store.state.highlight = store.state.units.filter(t => isBattleUnit(t) && t.team !== u.team && dist(u, t) <= u.range && lineOfSight(store.board, u, t)).map(t => ({ x: t.x, y: t.y }));
    // Geschlossene Cores sind Angriffsziele; ein bereits geöffneter Kern nicht mehr.
    // Feindliche Einheiten dürfen Cores nicht angreifen, daher werden sie ihnen auch nicht als Ziel angezeigt.
    if (u.team !== "enemy") for (const core of store.state.cores) {
      if (!isCoreOpen(core) && core.hp > 0 && dist(u, core) <= u.range && lineOfSight(store.board, u, core)) store.state.highlight.push({ x: core.x, y: core.y });
    }
  }
  if (mode === "ability") {
    if (u.abilityType === "trap") {
      // BUGFIX: Reichweite der Mine folgt jetzt dem range-Stat der Einheit (vorher
      // hartcodiert auf die 4 Nachbarfelder, unabhängig davon, was im Editor eingestellt war).
      const cells = [], reach = abilityReach(u);
      for (let dy = -reach; dy <= reach; dy++) {
        for (let dx = -reach; dx <= reach; dx++) {
          if (!dx && !dy) continue;
          const x = u.x + dx, y = u.y + dy;
          if (dist(u, { x, y }) > reach) continue;
          if (canEnter(u, x, y) && !store.state.traps.some(t => t.x === x && t.y === y)) cells.push({ x, y });
        }
      }
      store.state.highlight = cells;
    }
    else if (u.abilityType === "heal") store.state.highlight = store.state.units.filter(t => isBattleUnit(t) && t.team === u.team && t.hp < t.maxHp && dist(u, t) <= abilityReach(u) && lineOfSight(store.board, u, t)).map(t => ({ x: t.x, y: t.y }));
    else store.state.highlight = store.state.units.filter(t => isBattleUnit(t) && t.team !== u.team && dist(u, t) <= abilityReach(u) && lineOfSight(store.board, u, t)).map(t => ({ x: t.x, y: t.y }));
  }
  render();
}
