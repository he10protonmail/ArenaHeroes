import { getCell, isPassable, lineOfSight } from "./board.js";
import { isBattleUnit } from "./units.js";
import { store } from "./store.js";

export function getCurrentUnit() {
  return store.state.turnOrder[store.state.turnIndex] || null;
}
export function at(x, y) {
  return store.state.units.find(u => isBattleUnit(u) && u.x === x && u.y === y) || null;
}
// Wie at(), findet aber auch besiegte/nicht-im-Kampf-befindliche Einheiten (für den Editor).
export function atAny(x, y) {
  return store.state.units.find(u => isBattleUnit(u) && u.x === x && u.y === y)
    || store.state.units.find(u => u.x === x && u.y === y) || null;
}
export function dist(a, b) {
  return Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y));
}
export function hasStatus(e, id) {
  return !!e?.statuses?.some(s => s.id === id);
}
export function effectiveDefense(unit) {
  const cell = getCell(store.board, unit?.x, unit?.y);
  const cover = Number(cell?.cover || 0);
  return Math.max(0, Number(unit?.defense || 0) + cover - (hasStatus(unit, "marked") ? 5 : 0));
}
export function canEnter(unit, x, y, ignoreUnitId = null) {
  const c = getCell(store.board, x, y);
  return isPassable(c, unit) && !store.state.units.some(u => isBattleUnit(u) && u.id !== ignoreUnitId && u.x === x && u.y === y);
}
// --- Cores (mehrere möglich, jeder mit eigenem Namen "Core N") ---
export function coreAt(x, y) {
  return store.state.cores.find(c => c.x === x && c.y === y) || null;
}
// Ist dieser Kern begehbar? Entweder von Anfang an so eingestellt (Editor:
// "Begehbar: Ja"), oder weil der Schalter (Kern-HP <= 0) ausgelöst wurde - siehe
// executeCoreAttack(). Zentrale Stelle, damit sich checkMission/executeCoreAttack/
// activateMode nicht jeweils eine eigene Kopie dieser Regel merken müssen.
export function isCoreOpen(core) {
  return !!core && !!getCell(store.board, core.x, core.y)?.walk;
}
export function heroOnCore(core) {
  return !!core && store.state.units.some(u => u.team === "hero" && u.alive && u.x === core.x && u.y === core.y);
}
// Alle Felder, die diese Einheit mit ihrer Reichweite angreifen könnte (Chebyshev-
// Distanz <= range und freie Sichtlinie - dieselben Regeln wie beim Angriff).
// Hindernisse selbst (Wände, Container ...) sind keine Ziele und werden ausgespart;
// Ausnahme: Cores, die man ja beschießen kann.
export function attackRangeTiles(unit) {
  const tiles = [];
  const r = Math.floor(Number(unit?.range) || 0);
  if (!unit || r < 1) return tiles;
  for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
    if (!dx && !dy) continue;
    const x = unit.x + dx, y = unit.y + dy;
    const cell = getCell(store.board, x, y);
    if (!cell) continue;
    if (cell.los && !coreAt(x, y)) continue;
    if (!lineOfSight(store.board, unit, { x, y })) continue;
    tiles.push({ x, y });
  }
  return tiles;
}
// Grund, warum eine Einheit nicht auf (x,y) stehen kann – leerer String, wenn alles passt.
export function placementError(u, x, y, ignoreId = null) {
  const cell = getCell(store.board, x, y);
  if (!cell) return "Outside the map.";
  if (!isPassable(cell, u)) return "This tile is not walkable.";
  const o = atAny(x, y);
  if (o && o.id !== ignoreId) return `The tile is already occupied by "${o.name}".`;
  return "";
}

// Steuert gerade die Gegner-KI? (KI an, Kampf läuft, aktive Einheit ist ein Gegner)
// Solange das so ist, sind Spieler-Eingaben im Kampf gesperrt.
export function isAiTurn() {
  const u = getCurrentUnit();
  return !!store.aiEnabled && store.state.screen === "battle" && !store.state.victory && !store.state.defeat && u?.team === "enemy";
}

// Reichweite der Spezialfähigkeit (kann größer/kleiner als die Angriffsreichweite sein, z. B. Devias Peitsche).
export function abilityReach(unit) {
  return Math.max(0, Math.floor(Number(unit?.abilityRange ?? unit?.range) || 0));
}

