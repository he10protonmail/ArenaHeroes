import { store, resetBoard } from "./store.js";
import { COLS } from "./state.js";
import { PRESETS } from "./presets.js";
import { terrainTools, templates } from "./config.js";
import { DEFAULT_TERRAIN } from "./board.js";
import { render, showRangePreview } from "./render.js";
import { delegatedClick } from "./ui.js";
import { loadScenario, restoreBattle, startBattle, openEditor, endTurn, activateMode, clickBattleTile, setAiEnabled } from "./battle.js";
import {
  clickEditorTile, startEditUnit, createCustomUnitAtEditor, saveUnitDraft, cancelUnitDraft,
  deleteEditedUnit, saveTerrain, saveEditableMap, loadEditableMap, loadPreset, clearEditableMap,
  moveUnitInEditor, startNewUnitDraft, readUnitImage
} from "./editor.js";

function buildStaticShell() {
  const w = document.getElementById("workspace");
  w.innerHTML = `<div id="battle-screen" class="screen"><div id="board-container"><div id="board"></div><div id="fx-layer"></div><div id="battle-overlay" class="battle-overlay hidden"></div></div><aside id="sidebar">
  <div class="panel"><h3 id="battle-state-title">Battle</h3><p id="battle-round-label"></p><div id="selected-unit-card"></div></div>
  <div class="panel"><h3>Actions</h3><button class="action-btn" data-action="move">Move (M)</button> <button class="action-btn" data-action="attack">Attack (A)</button> <button class="action-btn" data-action="ability">Special (S)</button> <button class="action-btn success" data-action="end-turn">Next (N)</button><button id="ai-toggle-btn" class="success" style="display:block;width:100%;margin-top:8px" type="button" data-action="toggle-ai" title="Toggle enemy AI">Enemy AI: ON</button><div class="small" style="margin-top:8px">Keys: M move · A attack · S special · N next · Esc cancel</div></div>
  <div class="panel"><h3>Mission goals</h3><div id="mission-list"></div></div>
  <div class="panel"><h3>Initiative</h3><div id="initiative-list"></div></div><div class="panel"><h3>Log</h3><div id="battle-log"></div></div></aside></div>
  <div id="editor-screen" class="screen hidden"><div id="board-container-editor"><div id="editor-board"></div></div><aside id="sidebar-editor"><div id="editor-notice" class="notice hidden" role="status"></div>
  <div class="panel"><h3>Editor tools</h3><div class="editor-tools">${["select", ...terrainTools, "unit", "delete"].map(t => `<button data-tool="${t}">${t === "select" ? "Select" : t === "unit" ? "Unit" : t === "delete" ? "Delete" : DEFAULT_TERRAIN[t]?.label || t}</button>`).join("")}</div><div class="small">With "Unit" you can pick a template type below. With "Select", clicking a tile opens the terrain editor.</div><div id="template-tools"></div></div>
  <div class="panel"><h3>Units</h3><div id="unit-list" class="unit-editor-list"></div><button id="new-unit-btn" class="wide success">New unit</button></div>
  <div class="panel"><h3>Edit unit / terrain</h3><div id="unit-form"></div></div>
  <div class="panel"><h3>Map</h3><button id="save-map-btn" class="wide success">Save map</button><button id="load-map-btn" class="wide">Load map</button><button id="clear-map-btn" class="wide warning">Clear map</button><button id="test-map-btn" class="wide primary">Test map</button><div class="small" style="margin-top:8px">Built-in maps</div><select id="preset-select" class="input" style="margin:4px 0">${PRESETS.map(p => `<option value="${p.id}">${p.label}</option>`).join("")}</select><button id="load-preset-btn" class="wide">Load preset</button></div></aside></div>`;
  w.addEventListener("change", async e => {
    if (e.target.id !== "unit-image") return;
    const data = await readUnitImage(e.target.files?.[0]);
    const pv = document.getElementById("unit-preview");
    if (pv && data) pv.style.backgroundImage = `url("${data}")`;
    if (data && store.state.editorDraft) store.state.editorDraft.unit.image = data;
  });
  // Mauszeiger über einer Einheit zeigt deren Angriffsreichweite (für Helden und Gegner)
  w.addEventListener("mouseover", e => {
    if (store.state.screen !== "battle") return;
    const board = document.getElementById("board");
    const id = e.target.closest?.("#board .unit")?.dataset.unitId || "";
    if (board && (board.dataset.rangeFor || "") !== id) showRangePreview(id);
  });
  w.addEventListener("mouseleave", () => showRangePreview(""));
  w.addEventListener("dragstart", e => {
    const n = e.target.closest?.("#editor-board .unit"); if (!n || store.state.screen !== "editor") return;
    e.dataTransfer.setData("text/plain", n.dataset.unitId); e.dataTransfer.effectAllowed = "move";
  });
  w.addEventListener("dragover", e => { if (store.state.screen === "editor" && e.target.closest?.("#editor-board .tile")) e.preventDefault(); });
  w.addEventListener("drop", e => {
    const t = e.target.closest?.("#editor-board .tile"); if (!t || store.state.screen !== "editor") return;
    e.preventDefault();
    moveUnitInEditor(e.dataTransfer.getData("text/plain"), Number(t.dataset.x), Number(t.dataset.y));
    render();
  });
  delegatedClick(w, "[data-template]", b => {
    const key = b.dataset.template || null; store.state.editorSelected = key;
    if (store.state.editorDraft?.isNew) {
      const { x, y } = store.state.editorDraft.unit, t = templates[key] ? { ...templates[key] } : null;
      startNewUnitDraft(t ? { ...t, x, y } : { x, y });
    }
    render();
  });
  delegatedClick(w, "[data-action]", b => { const a = b.dataset.action; if (a === "move" || a === "attack" || a === "ability") activateMode(a); if (a === "end-turn") endTurn(); if (a === "toggle-ai") setAiEnabled(!store.aiEnabled); if (a === "restore-battle") restoreBattle(); });
  delegatedClick(w, ".tile", t => { const x = Number(t.dataset.x), y = Number(t.dataset.y); store.state.screen === "battle" ? clickBattleTile(x, y) : clickEditorTile(x, y); render(); });
  delegatedClick(w, "[data-tool]", b => { store.state.tool = b.dataset.tool; if (store.state.tool !== "unit") store.state.editorSelected = null; render(); });
  delegatedClick(w, "[data-unit-id]", b => { const u = store.state.units.find(x => x.id === b.dataset.unitId); if (u) startEditUnit(u); render(); });
  delegatedClick(w, "#new-unit-btn", createCustomUnitAtEditor); delegatedClick(w, "#save-unit-btn", saveUnitDraft); delegatedClick(w, "#cancel-unit-btn", cancelUnitDraft); delegatedClick(w, "#delete-unit-btn", deleteEditedUnit); delegatedClick(w, "#save-terrain-btn", saveTerrain);
  delegatedClick(w, "#save-map-btn", saveEditableMap); delegatedClick(w, "#load-map-btn", loadEditableMap); delegatedClick(w, "#clear-map-btn", clearEditableMap);
  delegatedClick(w, "#test-map-btn", startBattle);
  delegatedClick(w, "#load-preset-btn", () => loadPreset(document.getElementById("preset-select").value));
  // Meldung des Editors bei jedem neuen Klick zuerst löschen (Capture-Phase, läuft vor den anderen Handlern)
  w.addEventListener("click", () => { store.state.notice = ""; }, true);
  document.getElementById("battle-button").onclick = () => { if (store.state.screen !== "battle") startBattle(); };
  document.getElementById("editor-button").onclick = () => { if (store.state.screen !== "editor") openEditor(); };
  document.getElementById("abort-button").onclick = () => { if (store.state.screen === "battle") restoreBattle(); };
}
// Keyboard shortcuts for the battle screen (alternative to the mouse): M move, A attack, S special ability,
// N next unit (end turn), Esc cancels the current action mode. Ignored while typing in form fields.
function onKeyDown(e) {
  if (e.ctrlKey || e.metaKey || e.altKey || e.repeat) return;
  const t = e.target;
  if (t?.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t?.tagName || "")) return;
  if (store.state.screen !== "battle" || store.state.victory || store.state.defeat) return;
  const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  const actions = { m: () => activateMode("move"), a: () => activateMode("attack"), s: () => activateMode("ability"), n: () => endTurn(),
    Escape: () => { if (store.state.mode) { store.state.mode = null; store.state.highlight = []; render(); } } };
  if (!actions[key]) return;
  e.preventDefault(); actions[key]();
}
function init() {
  document.addEventListener("keydown", onKeyDown);
  document.documentElement.style.setProperty("--cols", COLS); // Spaltenzahl für Raster und Kachelgröße (style.css)
  document.title = "Tactical BattleGrid – Build 14"; // Kontrolle: steht dieser Titel im Tab, wird die aktuelle main.js geladen
  buildStaticShell(); resetBoard(); loadScenario(); store.state.screen = "battle"; render();
}
document.addEventListener("DOMContentLoaded", init);
