import { ROWS, COLS } from "./state.js";

export const DEFAULT_TERRAIN = Object.freeze({
  floor: { label: "Floor", walk: true, los: false, cover: 0 },
  wall: { label: "Wall", walk: false, los: true, cover: 2 },
  water: { label: "Water", walk: false, los: false, cover: 0 },
  tree: { label: "Tree", walk: false, los: true, cover: 1 },
  container: { label: "Container", walk: false, los: true, cover: 2 },
  vehicle: { label: "Vehicle", walk: false, los: true, cover: 2 },
  core: { label: "Core", walk: false, los: true, cover: 2 }
});

export function makeTerrain(type = "floor", image = "") {
  const base = DEFAULT_TERRAIN[type] || DEFAULT_TERRAIN.floor;
  return { type, walk: !!base.walk, los: !!base.los, cover: Number(base.cover || 0), image: image || "" };
}

export function createEmptyMap() {
  return Array.from({ length: ROWS }, () =>
    Array.from({ length: COLS }, () => makeTerrain("floor"))
  );
}

// Umrandet die Karte komplett mit Wänden (mutiert das übergebene board).
export function addBorderWalls(board) {
  for (let x = 0; x < COLS; x++) for (const y of [0, ROWS - 1]) Object.assign(getCell(board, x, y), makeTerrain("wall"));
  for (let y = 0; y < ROWS; y++) for (const x of [0, COLS - 1]) Object.assign(getCell(board, x, y), makeTerrain("wall"));
  return board;
}

export function getCell(board, x, y) {
  return Number.isInteger(x) && Number.isInteger(y) && x >= 0 && y >= 0 && x < COLS && y < ROWS
    ? board[y][x] : null;
}

export function lineOfSight(board, a, b) {
  const n = Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y));
  if (!n) return true;
  for (let i = 1; i <= n; i++) {
    const cx = a.x + Math.round((b.x - a.x) * i / n);
    const cy = a.y + Math.round((b.y - a.y) * i / n);
    const cell = getCell(board, cx, cy);
    if (cell?.los && !(cx === b.x && cy === b.y)) return false;
  }
  return true;
}

// Ist das Feld für diese Einheit betretbar? Wasser dürfen nur fliegende Einheiten
// betreten, alle anderen Felder richten sich nach dem "walk"-Flag.
export function isPassable(cell, unit) {
  if (!cell) return false;
  if (cell.type === "water") return !!unit?.flying;
  return !!cell.walk;
}

export function isDiagonalCornerBlocked(board, from, to, unit) {
  const dx = Math.sign(to.x - from.x);
  const dy = Math.sign(to.y - from.y);
  if (!dx || !dy) return false;
  const a = getCell(board, from.x + dx, from.y);
  const b = getCell(board, from.x, from.y + dy);
  return !isPassable(a, unit) || !isPassable(b, unit);
}

// Schachbrett-Koordinaten: Spalte als Buchstabe (A..Z, AA, AB ...), Zeile als Zahl von oben (1..ROWS).
export function colName(x) {
  let n = x + 1, s = "";
  while (n > 0) { const r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = Math.floor((n - 1) / 26); }
  return s;
}
export function coordLabel(x, y) { return `${colName(x)}${y + 1}`; }

// Umkehrung von coordLabel: "G18" -> { x: 6, y: 17 }. Ungültige oder außerhalb der Karte liegende Angaben ergeben null.
export function parseCoord(text) {
  const m = /^\s*([A-Za-z]{1,2})\s*(\d{1,2})\s*$/.exec(String(text ?? ""));
  if (!m) return null;
  const x = [...m[1].toUpperCase()].reduce((n, ch) => n * 26 + ch.charCodeAt(0) - 64, 0) - 1, y = Number(m[2]) - 1;
  return x >= 0 && x < COLS && y >= 0 && y < ROWS ? { x, y } : null;
}

