// Fertige Karten-Vorlagen ("Warehouse") für den Editor-Knopf "Load preset".
// DOM-frei: liefert Daten im gleichen Format wie eine gespeicherte Karte ({ board, units, cores }).
// Koordinaten sind Rasterwerte (x = Spalte 0..27 = A..AB, y = Zeile 0..19 = 1..20), wie am Kartenrand angezeigt.
// Jedes Szenario hat genau eine Devia und einen Bulwark; die Schwierigkeit steuert die Zahl der Drohnen (Zahlen aus Simulationen, siehe README, "Balancing").
import { createEmptyMap, addBorderWalls, makeTerrain } from "./board.js";
import { makeUnit } from "./units.js";
import { templates } from "./config.js";

const HERO_POS = { powerkim: [8, 16], visor: [6, 17], watson: [7, 17], nyra: [5, 16] }; // I17, G18, H18, F17
const DEVIA_POS = [21, 5]; // V6 - genau eine Devia pro Szenario
const BULWARK_POS = [25, 3]; // Z4 (beim Core) - genau ein Bulwark pro Szenario
const DRONE_SLOTS = [[22, 3], [23, 7], [24, 5], [22, 7], [24, 3], [25, 6], [20, 4], [23, 5]]; // W4, X8, Y6, W8, Y4, Z7, U5, X6
const CORE_SLOTS = [[26, 2], [26, 15]]; // AA3, AA16

function warehouseBoard() {
  const board = createEmptyMap(); addBorderWalls(board);
  const put = (x, y, type, extra = {}) => Object.assign(board[y][x], makeTerrain(type), extra);
  // Trennwand bei Spalte N (x 13) mit dreifeldrigem Tor N9-N11
  for (let y = 1; y <= 18; y++) if (y < 8 || y > 10) put(13, y, "wall");
  // Container: J13 K13 J14 | Q6 R6 Q7 | V10 V11 W10 | I6 I7 | S16 T16
  for (const [x, y] of [[9, 12], [10, 12], [9, 13], [16, 5], [17, 5], [16, 6], [21, 9], [21, 10], [22, 9], [8, 5], [8, 6], [18, 15], [19, 15]]) put(x, y, "container");
  // Bäume: G10 L7 P17 X16 Y7
  for (const [x, y] of [[6, 9], [11, 6], [15, 16], [23, 15], [24, 6]]) put(x, y, "tree");
  // Wasser (nur Flieger): R12 S12 R13 S13 T13
  for (const [x, y] of [[17, 11], [18, 11], [17, 12], [18, 12], [19, 12]]) put(x, y, "water");
  // Deckungsfelder (Boden mit Deckung 2): L16 M16 L11 M8 M12 O10 O9 P13 U7 U8 X5
  for (const [x, y] of [[11, 15], [12, 15], [11, 10], [12, 7], [12, 11], [14, 9], [14, 8], [15, 12], [20, 6], [20, 7], [23, 4]]) put(x, y, "floor", { cover: 2 });
  return board;
}

function build({ drones, cores }) {
  const board = warehouseBoard(), units = [];
  for (const [id, [x, y]] of Object.entries(HERO_POS)) units.push(makeUnit(templates[id], { x, y }));
  units.push(makeUnit(templates.devia, { x: DEVIA_POS[0], y: DEVIA_POS[1] }));
  units.push(makeUnit(templates.bulwark, { x: BULWARK_POS[0], y: BULWARK_POS[1] }));
  for (let i = 0; i < drones; i++) { const [x, y] = DRONE_SLOTS[i]; units.push(makeUnit(templates.drone1, { id: `drone${i + 1}`, name: `Security Drone ${i + 1}`, x, y })); }
  const coreList = [];
  for (let i = 0; i < cores; i++) {
    const [x, y] = CORE_SLOTS[i];
    Object.assign(board[y][x], makeTerrain("core"));
    coreList.push({ name: `Core ${i + 1}`, x, y, hp: 100, maxHp: 100, entered: false });
  }
  return { board, units, cores: coreList };
}

export const PRESETS = [
  { id: "easy", label: "Warehouse – Easy (Devia + Bulwark + 1 drone, 1 core)", cfg: { drones: 1, cores: 1 } },
  { id: "standard", label: "Warehouse – Standard (Devia + Bulwark + 2 drones, 1 core)", cfg: { drones: 2, cores: 1 } },
  { id: "hard", label: "Warehouse – Hard (Devia + Bulwark + 3 drones, 1 core)", cfg: { drones: 3, cores: 1 } },
  { id: "two-cores", label: "Warehouse – Two cores (Devia + Bulwark + 2 drones)", cfg: { drones: 2, cores: 2 } },
  { id: "brutal", label: "Warehouse – Brutal (Devia + Bulwark + 5 drones, 1 core)", cfg: { drones: 5, cores: 1 } }
];

export function buildPreset(id) {
  const p = PRESETS.find(x => x.id === id);
  return p ? { ...build(p.cfg), label: p.label } : null;
}
