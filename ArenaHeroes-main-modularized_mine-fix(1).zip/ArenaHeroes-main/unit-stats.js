// =====================================================================================================
//  UNIT STATS  -  hier stehen ALLE Werte der Figuren. Einfach Zahlen ändern, speichern und die
//  Seite mit Strg + F5 neu laden. (Gilt für das Standard-Szenario, die Vorlagen im Editor und die
//  Karten-Vorlagen "Warehouse". Karten, die du im Editor schon GESPEICHERT hast, behalten ihre eigenen
//  Werte - dort die Einheit im Editor ändern oder die Karte neu aus den Vorlagen aufbauen.)
//
//  Spielregeln in Kürze (damit man weiß, was eine Zahl bewirkt):
//   - Trefferwurf: W20 + attack - defense (des Ziels, plus Deckung) muss mindestens 11 ergeben.
//     Jeder Punkt Unterschied = 5 Prozentpunkte Trefferchance. Spezialfähigkeiten würfeln mit -5 Malus.
//   - Schaden: "damage" geht bei einem Treffer komplett durch (die Verteidigung wirkt nur beim Trefferwurf).
//   - Reihenfolge im Kampf: wer mehr "movement" hat, ist zuerst dran (bei Gleichstand: Reihenfolge in dieser Datei).
//   - Jede Einheit hat 2 Aktionspunkte pro Zug; Bewegen, Angriff und Spezialfähigkeit kosten je 1.
//
//  Felder:
//   name / short / className / color   Anzeige (short = Kürzel auf der Figur, color = #rrggbb)
//   team          "hero" oder "enemy"
//   start         Startfeld im Standard-Szenario, wie am Kartenrand: Spalte A-AB + Zeile 1-20 (z. B. "G18")
//   hp            Trefferpunkte
//   attack        Angriffswert (Trefferwurf)
//   defense       Verteidigung (Trefferwurf der Gegner gegen diese Figur)
//   movement      Bewegungsreichweite in Feldern pro Zug (diagonal zählt als 1 Feld)
//   range         Angriffsreichweite in Feldern (1 = nur Nachbarfelder)
//   damage        Schaden pro Treffer (Angriff und Spezialfähigkeit)
//   knockback     Rückstoß in Feldern bei Treffer (0 = keiner)
//   stability     Standfestigkeit gegen Umwerfen/Kollisionsschaden (höher = stabiler)
//   flying        true = Flieger (überquert Wasser)
//   abilityType   "none", "stun", "mark", "heal", "trap", "push" oder "pull"
//   abilityName   Name der Spezialfähigkeit (wird im Spiel angezeigt)
//   abilityRange  Reichweite der Spezialfähigkeit; null = wie range
//   heal          Heilmenge (nur für abilityType "heal")
//   trapDamage    Minenschaden (nur für abilityType "trap")
// =====================================================================================================

export const unitStats = {
  // ----------------------------------------------- HELDEN -----------------------------------------------
  powerkim: {
    name: "Powerkim", short: "P", team: "hero", className: "Melee / Tank", color: "#1686e6", start: "G18",
    hp: 180, attack: 20, defense: 18, movement: 4, range: 1, damage: 35, knockback: 3, stability: 25, flying: false,
    abilityType: "stun", abilityName: "Power Strike", abilityRange: null, heal: 0, trapDamage: 0
  },
  visor: {
    name: "Visor", short: "V", team: "hero", className: "Ranged / Tactician", color: "#7f66ff", start: "H18",
    hp: 80, attack: 22, defense: 10, movement: 4, range: 7, damage: 24, knockback: 1, stability: 12, flying: false,
    abilityType: "mark", abilityName: "Mark", abilityRange: null, heal: 0, trapDamage: 0
  },
  watson: {
    name: "Watson", short: "W", team: "hero", className: "Healer / Flying", color: "#53d7a0", start: "I18",
    hp: 100, attack: 8, defense: 10, movement: 5, range: 3, damage: 10, knockback: 0, stability: 10, flying: true,
    abilityType: "heal", abilityName: "Healing Beam", abilityRange: 6, heal: 40, trapDamage: 0
  },
  nyra: {
    name: "Nyra", short: "N", team: "hero", className: "Spy / Traps", color: "#d56cff", start: "F19",
    hp: 70, attack: 15, defense: 12, movement: 6, range: 1, damage: 18, knockback: 2, stability: 8, flying: false,
    abilityType: "trap", abilityName: "Mine", abilityRange: null, heal: 0, trapDamage: 30
  },

  // ---------------------------------------------- GEGNER ------------------------------------------------
  drone1: {
    name: "Security Drone 1", short: "D", team: "enemy", className: "Ranged / Flying", color: "#d24252", start: "U4",
    hp: 40, attack: 14, defense: 3, movement: 5, range: 6, damage: 14, knockback: 0, stability: 10, flying: true,
    abilityType: "none", abilityName: "None", abilityRange: null, heal: 0, trapDamage: 0
  },
  drone2: {
    name: "Security Drone 2", short: "D", team: "enemy", className: "Ranged / Flying", color: "#d24252", start: "V6",
    hp: 40, attack: 14, defense: 3, movement: 5, range: 6, damage: 14, knockback: 0, stability: 10, flying: true,
    abilityType: "none", abilityName: "None", abilityRange: null, heal: 0, trapDamage: 0
  },
  // Devia: Nahkämpferin mit Peitsche. Angriff nur auf Nachbarfelder (range 1); ihre Spezialfähigkeit "Whip Pull"
  // reicht 3 Felder weit (abilityRange) und zieht das Ziel bis direkt neben sie (Gegenteil von Knockback).
  devia: {
    name: "Devia", short: "Dv", team: "enemy", className: "Whip / Pull", color: "#c04dff", start: "R10",
    hp: 140, attack: 18, defense: 12, movement: 4, range: 1, damage: 22, knockback: 0, stability: 14, flying: false,
    abilityType: "pull", abilityName: "Whip Pull", abilityRange: 3, heal: 0, trapDamage: 0
  },
  bulwark: {
    name: "Bulwark", short: "B", team: "enemy", className: "Heavy Tank", color: "#b24d4d", start: "T16",
    hp: 220, attack: 26, defense: 20, movement: 3, range: 1, damage: 16, knockback: 3, stability: 30, flying: false,
    abilityType: "none", abilityName: "None", abilityRange: null, heal: 0, trapDamage: 0
  }
};
