# Tactical BattleGrid (früher „Arena Heroes“)
Taktisches Rundenkampf-Browserspiel mit Karteneditor (reines HTML/CSS/JavaScript, keine Abhängigkeiten).

## Starten
Die Seite lädt ES-Module (`<script type="module">`). Ein Doppelklick auf `index.html` (file://) funktioniert
deshalb in Chrome/Edge **nicht** (leere Seite). Stattdessen einen kleinen Webserver starten:

```
cd ArenaHeroes-main   # Ordnername unverändert; darf beliebig umbenannt werden
python3 -m http.server 8000
```
und `http://localhost:8000` öffnen (oder das Repo über GitHub Pages veröffentlichen).

## Bedienung
**Kampf:** Held anklicken = aktive Figur wählen. Aktion wählen (Bewegen / Angriff / Fähigkeit), dann ein markiertes
Feld anklicken. Nochmal auf denselben Aktions-Button klicken bricht die Aktion ab. Jede Figur hat 2 Aktionspunkte
pro Runde; „Zug beenden“ gibt den Zug weiter. Die Gegner werden standardmäßig von einer einfachen KI gesteuert (Knopf „Enemy AI: ON/OFF“
im Panel „Actions“). Mit ausgeschalteter KI spielst du sie selbst (Hot-Seat). Ziel: Core betreten (Karte ohne Core: alle Gegner besiegen).

**Editor:** Werkzeug wählen und Felder anklicken. „Einheit“ setzt eine neue Figur dort, wo du klickst
(Vorschau als Geist, erneuter Klick verschiebt sie). Vorhandene Figuren lassen sich mit der Maus ziehen.
Neue Figuren werden durchnummeriert. „Karte testen“ startet den Kampf mit der aktuellen Karte;
Zurück im Editor ist die Karte wieder auf dem Stand vor dem Kampf. Gespeichert wird im localStorage des Browsers.

## Dateien
- `index.html`, `style.css`, `js/*.js` – das Spiel, aufgeteilt in fachliche Module (siehe unten)

### Modulaufbau (js/)
- `state.js`, `board.js`, `units.js`, `combat.js`, `storage.js`, `ui.js` – reine, DOM-freie Spiellogik/Utilities (unverändert)
- `config.js` – statische Daten: Einheiten-Vorlagen, Geländewerkzeuge
- `store.js` – gemeinsamer Zustand (`board`, `state`, Kampf-Snapshot) plus `resetBoard()`/`notify()`
- `selectors.js` – reine Lese-Abfragen auf dem Store (`getCurrentUnit`, `dist`, `effectiveDefense`, `canEnter`, `placementError`, …)
- `battle.js` – Rundenablauf und Kampfaktionen (Bewegen, Angriff, Fähigkeiten, Knockback, Minen) sowie die Gegner-KI
- `editor.js` – Karteneditor (Einheiten-/Gelände-Formulare, Karte speichern/laden, Bild-Upload)
- `render.js` – sämtliches Rendering (Board, Sidebar, Formulare)
- `main.js` – nur noch Bootstrapping: DOM-Grundgerüst aufbauen, Events verdrahten, `init()`

## Fixes
- Trefferwurf und Schadensberechnung getrennt: Verteidigung wird bei normalen Angriffen und Core-Angriffen nicht mehr doppelt berücksichtigt.
- Ungültiger CSS-Farbwert `#fff09` (5-stelliger Hex-Code, von Browsern ignoriert) in `.card`/`.unit-item`/`.terrain-item`/`.entry` durch `rgba(255,255,255,.05)` ersetzt.
- Minen-Reichweite der Fallen-Fähigkeit (`abilityType: "trap"`) folgt jetzt dem `range`-Stat der Einheit. Vorher war sie hartcodiert auf die 4 Nachbarfelder – eine im Editor geänderte Reichweite hatte keine Wirkung.
- Trefferformel neu balanciert: d20-basiert (`1-20 + Angriff - Verteidigung >= 11`), 50% Trefferchance bei Gleichstand, ±5%-Punkte je Differenz. Vorher: schon bei Gleichstand 83% Trefferchance, ab `Angriff > Verteidigung` bereits garantiert 100% Treffer unabhängig vom tatsächlichen Unterschied.
- Siegbedingung: Wenn eine Karte einen Core hat, war „alle Gegner besiegt" bisher **kein** gültiger Sieg mehr – ausschließlich `core.hp<=0` zählte. Jetzt gilt immer zusätzlich: alle Gegner besiegt = Sieg, unabhängig vom Core-Status.
- Board-Kacheln und Einheiten-/Status-Icons um ca. 20% vergrößert (60px → 72px Feldgröße, proportional mitskalierte Icons/HP-Anzeigen).
- Cores: mehrere pro Karte möglich, jeder neu gesetzte bekommt automatisch die nächste Nummer („Core 1“, „Core 2“ …; nach dem Löschen wird die höchste Nummer + 1 vergeben). Die Beschriftung steht auf dem Feld, im Tooltip, im Gelände-Formular, im Log und im Missionsziele-Panel. Jeder Kern startet (Standard) geschlossen mit HP und wirkt wie ein Schalter: erst auf 0 HP kämpfen macht ihn begehbar (grün pulsierend, kein Angriffsziel mehr), gewonnen wird aber erst, wenn eine Heldeneinheit ihn betritt. Ein betretener Kern bleibt „betreten“. Sieg = **alle** Cores betreten **oder** alle Feinde tot. Setzt man im Gelände-Editor „Begehbar: Ja“, ist der Kern von Anfang an offen. Karten-Speicherformat ist jetzt Version 4 (`cores`-Liste); alte Karten mit einzelnem `core` werden weiterhin geladen.
- Angriffsreichweite im Kampf: die aktive Einheit zeigt ihre Reichweite dauerhaft als Overlay (nur Felder mit freier Sichtlinie), Mauszeiger über einer beliebigen Einheit (Held oder Gegner) zeigt deren Reichweite als Vorschau; „Angriffsreichweite“ steht außerdem in der rechten Leiste direkt unter „Bewegung“ und „RW“ in der Initiative-Liste.
- Kampfende: großes „GAME OVER“ mit Ergebnis (SIEG/NIEDERLAGE) und Grund – „Alle Feinde sind tot“, „Core betreten“ bzw. „Alle Cores betreten“, „Alle Helden sind tot“. Der Grund wird beim Kampfende gespeichert (`endReason`).
- Bugfix: Eine Karte nur mit Core und ganz ohne Gegner galt nach der ersten Aktion sofort als „alle Feinde besiegt“ – „alle Feinde tot“ zählt jetzt nur, wenn die Karte überhaupt Gegner hat.
- Veraltete, nicht geladene Dateien `game.js` und `game.ja` entfernt.
- `restoreBattle()` setzt jetzt auch `screen = "battle"` (robuster gegen künftige Aufrufer außerhalb des Battle-Screens).
- Core-Status ("offen?"/"betreten?") in `isCoreOpen()`/`heroOnCore()` zentralisiert (`selectors.js`) statt an drei Stellen (`checkMission`, `executeCoreAttack`, `activateMode`) einzeln berechnet.
- Cores haben jetzt eine Lebensleiste auf dem Spielfeld (wie Einheiten), solange sie geschlossen sind und keine Einheit auf ihrem Feld steht.
- Bild-Vorschau im Editor (`style="background-image:url('...')"`) gegen manipulierte, von Hand bearbeitete Kartendateien abgesichert: nur echte `data:image/`-URLs werden interpoliert, `esc()` escaped jetzt auch Apostrophe.
- `clone()` nutzt `structuredClone()` statt JSON-Roundtrip (schneller, Fallback für alte Umgebungen bleibt erhalten).
- Kollisionsschaden-Formel kommentiert.
- Die übrigen Spielregeln wurden bewusst nicht verändert.

## Fixes (Kimi-Review 2)
- `.rv-hero` fehlte im CSS: die dauerhafte Reichweiten-Anzeige der aktiven **Helden**-Einheit war unsichtbar (nur Gegner hatten Farbe). Ergänzt, analog zu `.rv-enemy`.
- Bild-URL-Absicherung vereinheitlicht: neue zentrale `safeImageUrl()` in `render.js`, jetzt auch von `terrainStyle()` und den direkten `style.backgroundImage`-Zuweisungen (Einheiten-/Geist-Vorschau) genutzt, nicht mehr nur von `previewStyle()`.
- Storage-Key auf `arena-heroes-map-v4` umbenannt (bleibt auch nach der Umbenennung des Spiels in „Tactical BattleGrid“ unverändert, damit gespeicherte Karten erhalten bleiben) (passend zur Datenversion 4), mit einmaliger automatischer Migration einer evtl. noch vorhandenen Karte unter dem alten `v3`-Key.
- Bewegung: `movement: 0` (im Editor einstellbar, z.B. für einen stationären Geschützturm) bedeutet jetzt wirklich unbeweglich. Vorher gab die Rundenberechnung trotzdem mindestens 1 Bewegungspunkt.
- Einheiten-IDs der Start-Vorlagen (Powerkim, Visor, Watson, Nyra, die Drohnen, Bulwark) sind jetzt über `loadScenario()`-Aufrufe hinweg stabil, statt bei jedem Kampfstart neu zufällig generiert zu werden.
- Die bis dahin ungenutzten Kopfzeilen-Felder `#screen-title`/`#screen-status` zeigen jetzt den aktuellen Status ("Kampf – Runde 3 · Sieg" bzw. "Karten-Editor").
- Geprüft, aber bewusst NICHT übernommen: der gemeldete ungenutzte Import `isPassable` in `combat.js` wird tatsächlich verwendet (Zeile 17) – das war ein Fehlbefund im Review.

## Fixes (ChatGPT-Review 3, Priorität 1-5)
- **Doppelte IDs bei Vorlagen (Prio 1):** Eine neu erstellte Einheit aus einer Vorlage (z.B. Powerkim) übernahm bisher deren `id` mit - zwei Figuren mit identischer id konnten zu falscher Auswahl/Löschung/Zielsuche führen. Die frisch generierte `custom-…`-id einer neuen Figur wird jetzt nie mehr von der Vorlage überschrieben.
- **Fähigkeiten-Knockback (Prio 2, konkretes Beispiel):** Powerkims "Power-Schlag" (abilityType `stun`, `knockback: 3`) löste trotz gesetztem Knockback-Wert nie Rückstoß aus - nur `abilityType: "push"` rief `applyKnockback()` auf, und zwar mit hartcodierter Distanz 1 statt dem eigenen Stat. Jede offensive Fähigkeit nutzt jetzt einheitlich `u.knockback` (wie der normale Angriff). Ein vollständig von den Einheitenwerten getrenntes, eigenständiges Fähigkeiten-Datenmodell (wie im Review als Langfrist-Vorschlag skizziert) ist das NICHT - das wäre ein größerer Umbau, den ich bewusst nicht "mal eben" mitgemacht habe.
- **Knockdown ignorierte Stabilität (Prio 3):** Jede Kollision warf die Einheit bisher unabhängig von ihrer Stabilität um. Jetzt entscheidet `shouldKnockDown(force, stability)` - Wucht = Rückstoßdistanz × 10, verglichen mit dem `stability`-Wert der Einheit. Die genaue Schwelle ist meine eigene Kalibrierung (keine mir bekannte feste Spielregel), im Zweifel leicht nachjustierbar.
- **Kollisionsschaden traf nur die zurückgestoßene Einheit (Prio 4):** Prallt eine Einheit beim Rückstoß gegen eine andere, nimmt jetzt auch diese "Blocker"-Einheit Kollisionsschaden (und kann ebenfalls umgeworfen werden).
- **Schaden/Verteidigung-Konsistenz (Prio 5):** Geprüft - normaler Angriff und Fähigkeit wenden Verteidigung tatsächlich beide nur genau einmal an, nur an unterschiedlicher Stelle (Trefferwurf vs. direkter Schadensabzug, weil Fähigkeiten nie verfehlen). Das ist beabsichtigt, keine doppelte Anrechnung - jetzt an allen drei Stellen (`executeAttack`, `executeCoreAttack`, `executeAbility`) ausführlich verlinkt kommentiert, damit das nicht wieder als Bug missverstanden wird.
- Nyras Fallen-Ausbau (Netz-/Stolperfalle etc.) und Fahrzeug-Explosion stehen laut Review explizit unter "Danach", nicht "Sofort" - bewusst nicht mit umgesetzt.

## Comic-Treffer-Effekt
Bei jedem tatsächlichen Treffer (normaler Angriff, Kern-Angriff, Fähigkeitsschaden - nicht bei
Heilung, Fallen legen oder Fehlschlag) erscheint kurz eine comic-artige Sprechblase (zufällig aus
BANG!/PAFF!/WHAM!/KRACH!/BOOM!/ZACK!/WUMM!) plus ein roter Hit-Flash über der getroffenen Kachel.
Läuft auf einer eigenen `#fx-layer`-Ebene über dem Spielfeld, technisch notwendig, weil
`renderBoard()` bei jeder Aktion das komplette `#board` per `innerHTML` neu aufbaut - ein direkt
in eine Kachel gehängtes Element wäre sofort wieder weg. `playImpactFX(x, y)` in `render.js`
positioniert die Effekte per echter DOM-Geometrie (`offsetLeft`/`offsetTop` der Zielkachel), damit
nichts hartcodiert werden muss. Reine CSS-Animation (kein JS-Timing-Takt), räumt sich über
`setTimeout` passend zur Animationsdauer selbst ab.

## Gegner-KI, Statusanzeige, Review 3
- **Core-Schutz:** Feindliche Einheiten können Cores nicht beschädigen (auch nicht als Ziel markiert).
- **Statusanzeige:** Oben rechts im Fenster steht im Kampf, welche Einheit welchen Status hat (z. B. „Betäubt (1)“, Zahl = Restdauer).
- **Gegner-KI** (`battle.js`, Knopf im Panel „Actions“, Standard: AN): pro Zug 2 AP. Heiler heilen verletzte Verbündete;
  sonst wird der schwächste Held in Reichweite angegriffen (Angriffs-Fähigkeiten einmal pro Zug bevorzugt); Minenleger legen
  eine Mine auf das Feld in Reichweite, das den Helden am nächsten ist; sonst bewegt sich die Einheit auf ein Feld, von dem aus
  sie angreifen kann, bzw. auf kürzestem Weg zum nächsten Helden (Minen werden gemieden). Während die KI zieht, sind Spielereingaben gesperrt.
- **Minen** lösen jetzt auch bei erzwungener Bewegung aus (Rückstoß und Pull): Jede Mine auf dem Weg löst aus, nicht nur die am Zielfeld. Stirbt die Einheit dabei, endet die Bewegung sofort.
- **Farben** werden strikt auf `#rrggbb` geprüft (`safeColor()`), andere Werte fallen auf die Standardfarbe zurück.
- **Einheitendaten** werden in `makeUnit()` auf sinnvolle Bereiche begrenzt (Position innerhalb der Karte, HP ≤ Max-HP,
  gültiges Team, bekannte Fähigkeit/Status usw.) – schützt vor kaputten oder von Hand manipulierten Karten.
- **Kachelgröße** folgt der Fensterbreite (CSS-Variable `--ts`, 40–72 px); Einheiten, Lebensleisten und Minen skalieren mit.
- **Spezialfähigkeiten würfeln mit Malus:** Betäuben, Markieren, Push und Pull treffen nicht mehr automatisch. Der Trefferwurf
  ist derselbe d20-Wurf wie beim normalen Angriff, aber mit **-5** (= -25 Prozentpunkte Trefferchance, Konstante
  `ABILITY_HIT_MALUS` in `combat.js`). Bei einem Fehlschlag gibt es weder Schaden noch Status noch Rückstoß, der Aktionspunkt ist verbraucht.
  Die Verteidigung wirkt wie beim Angriff nur beim Wurf, nicht nochmal auf den Schaden. Heilen und Minen legen würfeln nicht.
  Die KI nutzt eine Fähigkeit nur, wenn ihre Trefferchance mindestens 35 % beträgt, sonst greift sie normal an.
- **Trefferchance-Anzeige:** Im Angriffs- und Fähigkeitsmodus steht auf jedem markierten Ziel (Gegner und Cores) ein kleines
  Prozent-Etikett (grün ab 65 %, gelb ab 35 %, sonst rot). Es nutzt dieselbe Formel wie der Wurf, bei Fähigkeiten inklusive Malus,
  und berücksichtigt Deckung und „Markiert“. Heilen und Minen legen zeigen nichts an, im KI-Zug ebenfalls nicht.
- **Bewegung/Reichweite gekürzt** (Start-Vorlagen in `config.js`, damit Positionieren wieder zählt - Bedrohung = Bewegung + Reichweite war bis zu 16 auf einer 19 Felder breiten Karte):
  Stand damals (Build 9): Powerkim 5→3, Visor 6→4 (Reichweite 10→7), Watson 8→5 (Reichweite 8→6), Nyra 9→6, Drohnen 8→5, Bulwark 3→2.
  **Die aktuellen Werte stehen in `unit-stats.js`** (siehe Abschnitt „Einheiten-Datei“ unten).
  Die Initiative-Reihenfolge bleibt gleich, weil sie nach Bewegung sortiert ist und alle Werte im selben Verhältnis sinken.
  Bereits im Editor gespeicherte Karten behalten ihre eigenen Werte.
- **Breiteres Spielfeld:** Die Karte ist jetzt 28 x 20 Felder (`COLS`/`ROWS`/`EXTRA_COLS` in `state.js`): links und rechts liegen je 4 zusätzliche
  Spalten. Die Startaufstellung ist um 4 Spalten nach rechts verschoben (gleiche Lage wie vorher, nur mit Platz an den Seiten).
  Der leere Rand links/rechts kam daher, dass `#game` auf 1700 px Breite begrenzt war - jetzt nutzt das Spiel die volle Fensterbreite.
  Die Kachelgröße (`--ts` in `style.css`, max. 72 px) wird aus Fensterbreite und Spaltenzahl berechnet, sodass das Feld ohne waagerechtes
  Scrollen neben die Seitenleiste passt (bei 2560 px Breite ca. 71 px). Mehr Spalten = kleinere Kacheln; bei sehr schmalen Fenstern (<1050 px) bleibt es beim Scrollen.
  Bereits gespeicherte 20 x 20-Karten werden beim Laden automatisch mittig eingepasst (Einheiten/Cores wandern um 4 nach rechts, die alten Randwände
  links/rechts werden zu Boden, die neue Außenkante bekommt Wände).

## Englische Oberfläche, Koordinaten, Tastenkürzel (Build 10)
- **Alle Anzeigen sind jetzt englisch** (Buttons, Panels, Editor, Log, Meldungen, Missionsziele, Game-Over-Anzeige, Status- und Fähigkeitsnamen,
  Geländenamen, Einheiten-Vorlagen; `lang="en"`). Kommentare im Code und diese README bleiben deutsch. Alte, im Editor gespeicherte Karten
  mit deutschen **Standard**texten (z. B. „Neue Figur 1“, „Betäuben“, „Eigene Einheit“) werden beim Laden automatisch übersetzt (`legacyText()` in `units.js`);
  selbst vergebene Namen bleiben unverändert.
- **Koordinaten am Spielfeldrand** im Schachbrett-Stil: Spalten als Buchstaben (A–Z, AA, AB) oben und unten, Zeilen als Zahlen (1–20, von oben) links und rechts,
  auf Kampffeld und Editor (`colName()`/`coordLabel()` in `board.js`, Darstellung `.coord` in `style.css`). Im Terrain-Formular steht z. B. „Tile B3 (x 1, y 2)“.
  Die X/Y-Felder im Einheiten-Formular bleiben 0-basiert (A1 = x 0, y 0).
- **Tastenkürzel im Kampf** (Alternative zur Maus): **M** Move, **A** Attack, **S** Special ability, **N** Next (Zug beenden), **Esc** Aktion abbrechen.
  Eine Taste zweimal drücken schaltet den Modus wieder aus; danach das Ziel wie gewohnt anklicken. Die Tasten sind in den Buttons beschriftet und werden ignoriert,
  wenn man in ein Eingabefeld tippt, Strg/Alt/Cmd gedrückt hält, die Taste gehalten wird (kein Mehrfach-„Next“), die KI am Zug ist, der Kampf vorbei ist oder der Editor offen ist.

## Karten-Vorlagen und Balancing (Build 14: je eine Devia + ein Bulwark + Drohnen)
- **Editor → Panel „Map“ → „Built-in maps“ + „Load preset“** lädt eine fertige Karte „Warehouse“ (`presets.js`) in den Editor. Gespeichert wird erst mit „Save map“,
  „Test map“ startet sie sofort als Kampf. **Jedes Szenario hat genau eine Devia und einen Bulwark; die Schwierigkeit steuert die Zahl der Drohnen:**
  **Easy** (1 Drohne, 1 Core), **Standard** (2 Drohnen), **Hard** (3 Drohnen), **Two cores** (2 Drohnen, 2 Cores), **Brutal** (5 Drohnen).
- **Aufstellung** (Spalte A–AB, Zeile 1–20): Helden Powerkim I17, Watson H18, Visor G18, Nyra F17; Devia V6; Bulwark Z4; Drohnen der Reihe nach W4, X8, Y6, W8, Y4, Z7, U5, X6;
  Cores AA3 und AA16. Die Gegner starten mindestens 12 Felder entfernt (Drohne: Bewegung 5 + Reichweite 6 = 11, Devia: 4 + 3 = 7), sodass in Runde 1 niemand schießt.
- **Gelände:** Trennwand N2–N18 mit Tor N9–N11; Container J13 K13 J14, Q6 R6 Q7, V10 V11 W10, I6 I7, S16 T16; Bäume G10 L7 P17 X16 Y7; Wasser R12 S12 R13 S13 T13 (nur Flieger);
  Deckungsfelder (Boden, Deckung 2) L16 M16 L11 M8 M12 O10 O9 P13 U7 U8 X5.
- **Simulationsergebnisse** (100 Kämpfe je Zeile, einfache KI auf beiden Seiten, also ein Mindestwert für menschliche Spieler; ±6 Prozentpunkte Rauschen).
  Siegquote der Helden bei „alle Gegner besiegen“ / bei „Core stürmen“:

  | Vorlage | alle besiegen | Core stürmen |
  |---|---|---|
  | Easy (1 Drohne) | 99 % | 90 % |
  | Standard (2 Drohnen) | 77 % | 94 % |
  | Hard (3 Drohnen) | 44 % | 61 % |
  | Two cores (2 Drohnen, 2 Cores) | 84 % | 79 % |
  | Brutal (5 Drohnen) | 4 % | 5 % |

  Stand: Build 14 (Werte aus `unit-stats.js`). Weitere Messpunkte mit Devia + Bulwark: ohne Drohne 99 % / 100 %, 4 Drohnen 15 % / 49 %, 6 Drohnen 1 % / 5 %.
  Jede zusätzliche Drohne kostet die Helden etwa 20–30 Prozentpunkte; Devia + Bulwark allein sind für die KI-Helden noch gut machbar. Die KI weicht nicht aus und sucht keine Deckung -
  für Menschen ist das Gelände deutlich stärker, die Vorlagen sind daher eher schwerer, als die Quote vermuten lässt.

## Einheiten-Datei, Devia, Pull (Build 12)
- **`unit-stats.js` (Projektwurzel, neben `index.html`)** enthält alle Figuren mit allen Werten (Trefferpunkte, Angriff, Verteidigung, Bewegung, Reichweiten,
  Schaden, Rückstoß, Fähigkeit, Startfeld wie „G18“ ...) zum Handeditieren; die Kommentare am Dateianfang erklären jedes Feld. Nach dem Speichern mit **Strg + F5** neu laden.
  `config.js` baut daraus die Vorlagen (Standard-Szenario, Editor-Vorlagen, „Warehouse“-Karten). Bereits im Editor gespeicherte Karten behalten ihre eigenen Werte.
  `abilityRange: null` bedeutet „wie `range`“. Ungültige Startfelder werden in der Konsole gemeldet und durch ein Ersatzfeld ersetzt.
- **Devia** (Gegner, `unit-stats.js`): Nahkämpferin, Bewegung 4, Angriffsreichweite 1. Spezialfähigkeit **Whip Pull** mit eigener Reichweite 3 (`abilityRange`): zieht einen Gegner
  bis direkt neben sich. Wie alle Fähigkeiten würfelt sie mit -5 Malus. Das Ziel wird Schritt für Schritt gezogen, bis es daneben steht oder ein Feld blockiert ist (Hindernis,
  Einheit, Wasser für Nicht-Flieger); Flieger werden auch über Wasser gezogen. Jede Mine auf dem Zugweg löst aus.
- **Neues Feld `abilityRange`** (Reichweite der Spezialfähigkeit, getrennt von `range`): im Editor-Formular „ability range“, im Infopanel als „Special range“ (nur wenn abweichend).
  Gilt für Heilen, Minen legen, Betäuben, Markieren, Push und Pull. Fehlt der Wert (alte Karten), gilt `range`.
- **Gegner-KI mit Pull:** Eine Pull-Einheit nutzt die Peitsche nur, wenn das Ziel nicht schon daneben steht, sich ziehen lässt und die Trefferchance (mit Malus) mindestens 35 % beträgt;
  danach greift sie im selben Zug an. Gegen Ziele mit hoher Verteidigung (z. B. Powerkim, 25 %) läuft sie stattdessen direkt hin.
- **Fehler behoben:** Das KI-Merkmal „Fähigkeit schon benutzt“ wurde nur bei einem Wechsel der Einheit zurückgesetzt. War nur noch eine Gegnerfigur übrig, setzte sie ihre Fähigkeit
  höchstens einmal im ganzen Kampf ein; jetzt gilt es pro Zug und Einheit.
- **Werteänderungen:** Drohnen-Reichweite 7→6, Powerkim Bewegung 3→4, Watson Angriffsreichweite 6→3 (Heilreichweite bleibt 6), Bulwark Bewegung 2→3.

## Umbenennung (Build 13)
Das Spiel heißt jetzt **Tactical BattleGrid** (Seitentitel, Überschrift im Spiel, Tab-Titel). Der Ordnername `ArenaHeroes-main` und der interne Speicher-Schlüssel
(`arena-heroes-map-v4`) bleiben absichtlich unverändert, damit der Server-Pfad und bereits gespeicherte Karten weiter funktionieren.

